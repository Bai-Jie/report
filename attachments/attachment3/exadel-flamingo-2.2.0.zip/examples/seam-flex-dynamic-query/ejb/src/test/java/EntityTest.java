import java.util.ArrayList;
import org.jboss.seam.mock.SeamTest;
import org.testng.annotations.Test;
import javax.persistence.EntityManager;
import com.exadel.flamingo.samples.seam.dynamicquery.Person;
import com.exadel.flamingo.service.seam.util.*;

public class EntityTest extends SeamTest
{   
    @Test
    public void testAddEntity() throws Exception {
   	
   	    new ComponentTest() {

            @Override
            protected void testComponents() throws Exception {
            	EntityManager entityManager = (EntityManager) getValue("#{entityManager}");
                AMFSeamMethodInvoker invoker = new AMFSeamMethodInvoker();
    	   
    	        assert invoker.makeCall("Person", "findAll", new Object[]{}) != null;
    	        //assert FlamingoUtils.makeCall("person", "findAll", new Object[]{}) != null;
    	        
    	        Person p = new Person();
    	        p.setName("Test Name");
    	        invoker.makeCall("Person", "save", new Object[]{p});
    	        
    	        p = (Person) ((ArrayList) invoker.makeCall("Person", "findByName",
    	            new Object[]{p.getName()})).get(0);
    	        assert p != null;
    	        p = (Person) ((ArrayList) invoker.makeCall("Person", "findByNameEqual",
    	        	new Object[]{p.getName()})).get(0);
    	        assert p != null;
    	        
    	        invoker.makeCall("Person", "remove", new Object[]{p});
    	        
    	        Person findPerson = (Person) entityManager.find(Person.class, new Integer(1));
    	        Person newFindPerson = (Person)((ArrayList) invoker.makeCall("Person", "findById", new Object[]{new Integer(1)})).get(0);
    	        
    	        assert findPerson.getId().equals(newFindPerson.getId());
    	        assert findPerson.getName().equals(newFindPerson.getName());
    	        
    	        ArrayList list = (ArrayList) invoker.makeCall("Person", "findByIdLessThan", new Object[]{new Integer(2)});
    	        assert list.size() == 1;
    	        
    	        list = (ArrayList) invoker.makeCall("Person", "findByIdLessThanEquals", new Object[]{new Integer(2)});
    	        assert list.size() == 2;
    	        
    	        list = (ArrayList) invoker.makeCall("Person", "findByIdGreaterThan", new Object[]{new Integer(2)});
                assert list.size() != 0;

    	        list = (ArrayList) invoker.makeCall("Person", "findByIdGreaterThanEquals", new Object[]{new Integer(2)});
                assert list.size() != 0;
                
                list = (ArrayList) invoker.makeCall("Person", "findByNameLike", new Object[]{"Alex"});
                assert list.size() == 1;
                
                list = (ArrayList) invoker.makeCall("Person", "findByNameNotLike", new Object[]{"Alex"});
                assert list.size() == 9;
                
                list = (ArrayList) invoker.makeCall("Person", "findByNameIsNotNull", new Object[]{});
                assert list.size() == 10;
                
                list = (ArrayList) invoker.makeCall("Person", "findByNameIsNull", new Object[]{});
                assert list.size() == 0;
                
                findPerson.setName(null);
                invoker.makeCall("Person", "save", new Object[]{findPerson});
                
                list = (ArrayList) invoker.makeCall("Person", "findByNameIsNull", new Object[]{});
                assert list.size() == 1;
                
                list = (ArrayList) invoker.makeCall("Person", "findByIdNotEqual", new Object[]{new Integer(1)});
                assert list.size() == 9;
            }       
        }.run();
   }
   
}