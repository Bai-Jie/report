/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.exadel.flamingo;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;

/**
 *
 * @author apleskatsevich
 */
@Name("DepartmentManagerBean")
@Scope(ScopeType.SESSION)
public class DepartmentManagerBean {
    
    @DataModel
    private List <Department> departmentList;

    @Factory("departmentList")
    public void createDepartments() {
        departmentList = new ArrayList<Department>();

        Department dep1 = new Department();
        dep1.setName("dep1");
        dep1.setManager(new PersonBean());
        dep1.getManager().setLastName("manager1");
        dep1.getManager().setFirstName("managerfirstName1");
        departmentList.add(dep1);


        Department dep2 = new Department();
        dep2.setName("dep2");
        dep2.setManager(new PersonBean());
        dep2.getManager().setLastName("manager2");
        dep2.getManager().setFirstName("managerfirstName2");
        
        PersonBean worker = new PersonBean();
        worker.setFirstName("workerFN1");
        worker.setLastName("workerLN1");
        dep2.getStaff().add(worker);
        
        departmentList.add(dep2);
    }
}
