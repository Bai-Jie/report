/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
 
package com.exadel.flamingo.javafx.samples.spring.helloworld;

public interface HelloService {

    String hello(String name);
}
