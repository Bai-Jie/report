/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
 
package com.exadel.flamingo.javafx.samples.spring.helloworld;

import com.caucho.hessian.client.HessianProxyFactory;
import java.net.MalformedURLException;


public class HelloworldClient {

    public static HelloworldClient CLIENT;
    
    private String _url;

    private HelloworldClient(String string) {
        _url = string;
    }
    private HelloService _service;

    public static void setServerUrl(String url) {
    	System.out.println("************* url = " + url);
        CLIENT = new HelloworldClient(url);
    }

    private HelloService getService() {
    	System.out.println("************* getService()");
        if (_service == null) {
            try {
                HessianProxyFactory factory = new HessianProxyFactory();


                _service = (HelloService) factory.create(HelloService.class, _url);
                System.out.println("************* _service = " + _service);
            } catch (MalformedURLException ex) {
                System.out.println(ex);
            }

        }

        return _service;
    }

    public String hello(String s) {
    	System.out.println("************* s = " + s);
        return getService().hello(s);
    }

    public static String getSomeString() {
    	return "SaySaySay!!!";
    }
}
