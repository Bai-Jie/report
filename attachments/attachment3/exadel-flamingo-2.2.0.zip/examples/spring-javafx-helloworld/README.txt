BUILD INSTRUCTIONS

You will need to perform a few steps before building a project with Maven:

1. Install JavaFX SDK (http://www.javafx.net/downloads/)  and set environment variable JAVAFX_HOME.

2. Generate a private key and a digital certificate. The Maven build needs them in order to sign the application.

    $cd web
    $ant -f build.xml create-keyEntry

    This command will generate a certificate whose validity period is 90 days. If you want to adjust it, you will
    need to edit "validity" attribute in the "web/build.xml" file.


NOTE:
    * You only need to perform these steps once. Once done, you can build the project the usual way by
      executing standard Maven goals: compile, package, install, etc.

    * In case if you acquire a real certificate from a certificate authority (CA):
        a. You will _not_ need to execute step 2.
        b. You will need to adjust properties in the file "web/security.properties" to reflect your keystore
           configuration.