package com.exadel.flamingo.push.samples.seam;

import com.exadel.flamingo.push.samples.AbstractInformationPublisher;
import com.exadel.flamingo.push.samples.InformationPublisher;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

/**
 *
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
@Name(InformationPublisher.NAME)
@Scope(ScopeType.APPLICATION)
public class SeamInformationPublisher extends AbstractInformationPublisher {
}
