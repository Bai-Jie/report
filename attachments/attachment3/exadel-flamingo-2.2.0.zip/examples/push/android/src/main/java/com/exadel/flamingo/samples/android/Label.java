/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-10-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.android;

import android.content.Context;
import android.widget.TextView;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class Label extends TextView {

	private String staticPart;

	public Label(Context context, String staticPart) {
		super(context);
		this.staticPart = staticPart;
		setText("");
	}

	@Override
	public void setText(CharSequence text, BufferType type) {
		super.setText(staticPart + text, type);
	}
}
