/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-11-2009
 * $Revision: 2644 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:15:52 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.android;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import com.exadel.flamingo.android.FlamingoApplication;
import com.exadel.flamingo.samples.push.android.R;
import java.net.URL;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public abstract class FlamingoSamplesParentActivity extends Activity {

	private static final LayoutParams LAYOUT_PARAMS = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT);
	private ViewGroup content;
	private ServerImplementationsWidget implementationsWidget;
	private ActionField serverURLField;
	private String serverUrl;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		content = new LinearLayout(this);
		content.setLayoutParams(LAYOUT_PARAMS);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		((LinearLayout) content).setOrientation(LinearLayout.VERTICAL);
		Display display = getWindowManager().getDefaultDisplay();
		int widthPadding = new Double(Math.round(display.getWidth() * 0.01)).intValue();
		int heightPadding = new Double(Math.round(display.getHeight() * 0.01)).intValue();
		content.setPadding(widthPadding, heightPadding, widthPadding, heightPadding);

		implementationsWidget = new ServerImplementationsWidget(this);
		content.addView(implementationsWidget);

		serverURLField = new ActionField(this, getString(R.string.serverURLLabel), getString(R.string.serverURLButton));
		serverURLField.getText().setText("http://<YOUR IP ADDRESS>:<PORT>");
		serverURLField.getActionButton().setOnClickListener(new Button.OnClickListener() {

			public void onClick(View view) {
				String server = Helper.getString(serverURLField);
				setServerURL(server);
			}
		});
		content.addView(serverURLField);
		setContentView(content);
	}

	private void setServerURL(String server) {
		if (server != null && server.trim().length() > 0) {
			try {
				String implementation = implementationsWidget.getImplementation();
				String url = createUrl(server, implementation);
				new URL(url).openConnection().connect();
				FlamingoApplication flamingoApplication = (FlamingoApplication) getApplication();
				flamingoApplication.initializeFlamingoServiceFactory(url);
				serverUrl = url;
				serverURLField.setEnabled(false);
				implementationsWidget.setEnabled(false);
				factoryInitialized();
			} catch (Exception exception) {
				serverURLField.getText().setError(exception.getLocalizedMessage());
				viewException(exception);
			}
		}
	}

	protected ViewGroup getContent() {
		return content;
	}

	protected void setContent(ViewGroup content) {
		this.content = content;
		setContentView(content);
	}

	protected void viewException(Exception exception) {
		Log.e(getClass().getName(), exception.getLocalizedMessage(), exception);
	}

	protected void factoryInitialized() {
	}

	protected abstract String createUrl(String server, String implementation);

	protected String getServerUrl() {
		return serverUrl;
	}
}
