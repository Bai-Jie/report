/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 29-12-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.push.android;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.exadel.flamingo.push.FlamingoMessage;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class FlamingoMessagesAdapter extends ArrayAdapter<FlamingoMessage> {

	public FlamingoMessagesAdapter(Context context) {
		super(context, 0);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		TextView view = new TextView(getContext());
		FlamingoMessage item = getItem(position);
		view.setText(String.valueOf(item.getPayloadData()));
		return view;
	}
}
