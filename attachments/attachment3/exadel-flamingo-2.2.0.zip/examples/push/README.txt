INSTRUCTIONS

	To run the example with JBoss 5 you need add code below to deploy/messaging/destinations-service.xml

	<mbean code="org.jboss.jms.server.destination.QueueService"
		   name="jboss.messaging.destination:service=Queue,name=testQueue"
		   xmbean-dd="xmdesc/Queue-xmbean.xml">
	  <depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
	  <depends>jboss.messaging:service=PostOffice</depends>
	  <attribute name="SecurityConfig">
		<security>
		  <role name="guest" read="true" write="true"/>
		  <role name="publisher" read="true" write="true" create="false"/>
		  <role name="noacc" read="false" write="false" create="false"/>
		</security>
	  </attribute>
	</mbean>

	<mbean code="org.jboss.jms.server.destination.QueueService"
		   name="jboss.messaging.destination:service=Queue,name=A"
		   xmbean-dd="xmdesc/Queue-xmbean.xml">
		<depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
		<depends>jboss.messaging:service=PostOffice</depends>
	</mbean>
	<mbean code="org.jboss.jms.server.destination.QueueService"
		   name="jboss.messaging.destination:service=Queue,name=B"
		   xmbean-dd="xmdesc/Queue-xmbean.xml">
		<depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
		<depends>jboss.messaging:service=PostOffice</depends>
	</mbean>
	<mbean code="org.jboss.jms.server.destination.QueueService"
		   name="jboss.messaging.destination:service=Queue,name=C"
		   xmbean-dd="xmdesc/Queue-xmbean.xml">
		<depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
		<depends>jboss.messaging:service=PostOffice</depends>
	</mbean>

1.	In order to build the Android UI, you must perform the following steps:

	1.1	Install Android SDK and Android Platform 1.6 (http://developer.android.com/sdk/index.html)

	1.2	Set environment variable ANDROID_HOME to path where you are installed Android

	1.3	Build example by command "mvn clean install -Pandroid"

	1.4	Deploy war (seam/spring) files to server

	1.5	To run Android example you should execute Android-emulator and deploy example to it by command
		"mvn com.jayway.maven.plugins.android.generation2:maven-android-plugin:deploy" in "android" folder

	1.6	You will need to specify the IP address of the server on which you deploy this example. If you run the server
		locally and you don't know your IP address, you can get it for example with the following command
		"sudo ifconfig eth0" under Linux or "ipconfig" under Windows

2.	In order to build the Swing UI, you must perform the following steps:

	2.1	Build example by command "mvn clean install -Pswing"

	2.2	Deploy war (seam/spring) files to server

	2.3	To run Swing example you should execute command "mvn assembly:assembly" in "swing" folder and execute example by
		command "java -jar target/push-sample-swing-1.0-SNAPSHOT-jar-with-dependencies.jar"

	2.4	You will need to specify the IP address (or name) of the server on which you deploy this example. If you run
		the server locally and you don't know your IP address, you can get it for example with the following command
		"sudo ifconfig eth0" under Linux or "ipconfig" under Windows

3.	In order to build the JavaFX UI, you must perform the following steps:

	3.1	Install JavaFX SDK (http://www.javafx.net/downloads/)

	3.2	Set environment variable JAVAFX_HOME to path where you are installed JavaFX

	3.3	Generate a private key and a digital certificate. The Maven build needs them in order to sign the application.

		$cd javafx
		$ant -f build.xml create-keyEntry

		This command will generate a certificate whose validity period is 90 days. If you want to adjust it, you will
		need to edit "validity" attribute in the "javafx/build.xml" file.

		NOTE:
			*	You only need to perform these steps once. Once done, you can build the project the usual way by
				executing standard Maven goals: compile, package, install, etc.

			*	In case if you acquire a real certificate from a certificate authority (CA):
				a.	You will _not_ need to execute step 3.3.
				b.	You will need to adjust properties in the file "javafx/security.properties" to reflect your
					keystore configuration.

	3.4	Build example by command "mvn clean install -Pjavafx"

	3.5	Deploy war (seam/spring) files to server

	3.6	To run the examples on JavaFX you should call the web-application, for example, using such reference
		http://localhost:8080/seam-push-sample/ or http://localhost:8080/spring-push-sample/
