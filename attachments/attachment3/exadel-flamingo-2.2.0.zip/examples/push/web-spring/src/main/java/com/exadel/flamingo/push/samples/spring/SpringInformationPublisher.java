package com.exadel.flamingo.push.samples.spring;

import com.exadel.flamingo.push.samples.AbstractInformationPublisher;
import com.exadel.flamingo.push.samples.InformationPublisher;
import com.exadel.flamingo.push.server.ServerSideBroker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 *
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
@Service(InformationPublisher.NAME)
@Scope(BeanDefinition.SCOPE_SINGLETON)
public class SpringInformationPublisher extends AbstractInformationPublisher {

	@Override
	@Autowired
	public void setServerSideBroker(ServerSideBroker serverSideBroker) {
		super.setServerSideBroker(serverSideBroker);
	}
}
