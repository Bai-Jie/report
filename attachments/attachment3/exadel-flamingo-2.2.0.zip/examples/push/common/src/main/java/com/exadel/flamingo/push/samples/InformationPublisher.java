package com.exadel.flamingo.push.samples;

import com.exadel.flamingo.FlamingoException;
import java.io.Serializable;

/**
 *
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public interface InformationPublisher extends Serializable {

	String NAME = "com.exadel.flamingo.push.samples.publisher";

	void start() throws FlamingoException;

	void setPeriod(int period) throws FlamingoException;

	void stop() throws FlamingoException;

	String[] getServerNames();
}
