/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 27-11-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.swing;

import com.exadel.flamingo.java.ServiceFactory;
import com.exadel.flamingo.utils.EmptyReturnCommand;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JFrame;
import javax.swing.UIManager;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public abstract class FlamingoSamplesParentFrame<Content extends FlamingoSamplesParentContent> extends JFrame {

	private ServerURLCreationComponent serverURLComponent = new ServerURLCreationComponent();
	private Content content;

	public FlamingoSamplesParentFrame(String demoName, String samplePattern) {
		content = createContent();
		content.setMainFrame(this);
		content.additionalInitialization();
		getContentPane().add(content, java.awt.BorderLayout.CENTER);
		getContentPane().add(serverURLComponent, java.awt.BorderLayout.NORTH);
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle(demoName);
		pack();
		serverURLComponent.setSamplePattern(samplePattern);
		serverURLComponent.addPropertyChangeListener(ServerURLCreationComponent.PROPERTY_URL, new PropertyChangeListener() {

			public void propertyChange(PropertyChangeEvent evt) {
				if (ServerURLCreationComponent.PROPERTY_URL.equals(evt.getPropertyName())) {
					String serverComponentURL = String.valueOf(evt.getNewValue());
					ServiceFactory.initialize(serverComponentURL);
					factoryInitialized();
				}
			}
		});
	}

	protected ServerURLCreationComponent getServerURLComponent() {
		return serverURLComponent;
	}

	protected Content getContent() {
		return content;
	}

	protected void factoryInitialized() {
		content.factoryInitialized();
	}

	protected abstract Content createContent();

	public void viewException(Exception exception) {
//		JOptionPane.showMessageDialog(ExpressionSampleMainFrame.this, exception.getLocalizedMessage());
		exception.printStackTrace();
	}

	protected static void defaultMain(final Class<? extends FlamingoSamplesParentFrame> sampleClass, String args[]) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		java.awt.EventQueue.invokeLater(new Runnable() {

			public void run() {
				new EmptyReturnCommand() {

					@Override
					protected void processingWithoutReturn() throws Exception {
						sampleClass.newInstance().setVisible(true);
					}
				}.execute();
			}
		});
	}
}
