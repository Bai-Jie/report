/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 25-12-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.push.samples.swing;

import com.exadel.flamingo.samples.swing.FlamingoSamplesParentFrame;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class OfflineSampleMainFrame extends FlamingoSamplesParentFrame<OfflineSampleContent> {

	public OfflineSampleMainFrame() {
		super("Flamingo Client Push Offline Demo", "{0}-push-sample");
	}

	@Override
	protected OfflineSampleContent createContent() {
		return new OfflineSampleContent();
	}

	public static void main(String args[]) {
		defaultMain(OfflineSampleMainFrame.class, args);
	}
}
