/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 27-11-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.swing;

import javax.swing.JPanel;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class FlamingoSamplesParentContent<MainFrame extends FlamingoSamplesParentFrame<?>> extends JPanel {

	private MainFrame mainFrame;

	protected MainFrame getMainFrame() {
		return mainFrame;
	}

	protected void setMainFrame(MainFrame mainFrame) {
		this.mainFrame = mainFrame;
	}

	protected void factoryInitialized() {
	}

	protected void additionalInitialization() {
	}

	protected String createServletURL(String servletPath) {
		return getMainFrame().getServerURLComponent().createServletURL(servletPath);
	}
}
