/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 10-11-2009
 * $Revision: 2531 $
 * Last modified: $Author: dkorotych $ $Date: 2009-11-10 08:08:02 -0800 (Tue, 10 Nov 2009) $
 */
package com.exadel.flamingo.push.samples.swing;

import com.exadel.flamingo.push.client.MessageStorage;
import com.exadel.flamingo.push.client.java.ClientSideBroker;
import com.exadel.flamingo.push.client.mode.Mode;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class DebugClientSideBroker extends ClientSideBroker {

	DebugClientSideBroker() {
	}

	DebugClientSideBroker(int messagesPollPeriod, int connectionPollPeriod, String pollingServletURL) {
		super(messagesPollPeriod, connectionPollPeriod, pollingServletURL);
	}

	DebugClientSideBroker(int messagesPollPeriod, int connectionPollPeriod, String pollingServletURL, Mode mode, boolean startOnCreate) {
		super(messagesPollPeriod, connectionPollPeriod, pollingServletURL, mode, startOnCreate);
	}

	@Override
	public MessageStorage getStorage() {
		return super.getStorage();
	}
}
