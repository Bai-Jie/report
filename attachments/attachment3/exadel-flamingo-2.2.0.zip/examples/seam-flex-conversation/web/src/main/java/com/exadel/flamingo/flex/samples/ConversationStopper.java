/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo.flex.samples;

import org.jboss.seam.annotations.End;
import org.jboss.seam.annotations.Name;

/**
 *
 * @author apleskatsevich
 */
@Name("conversationStopper")
public class ConversationStopper {
    
    @End()
    public void stop() {
        
    }
}
