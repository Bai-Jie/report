To run Exadel Flamingo Spring-Booking demo, you need HSQL or other database
configured in applicationContext.xml. When using not HSQL consider adding proper dependency to pom.xml

For deployment to JBossAS, uncomment marked lines in web/pom.xml
