package org.springframework.webflow.samples.booking;

/**
 * Interface for password changing.
 *
 * @author apleskatsevich
 */
public interface ChangePassword {
    
    /**
     * Updates password for particular user.
     * 
     * @param username Username
     * @param password New password to set
     * @return navigation rule
     */
    public String changePassword(String username, String password);
    
    /**
     * Sets value to verify password.
     * @param verifyPassword Value to verify
     */
    public void setVerifyPassword(String verifyPassword);
    
    /**
     * Gets value to verify password.
     * @return verify password value
     */   
    public String getVerifyPassword(); 
}
