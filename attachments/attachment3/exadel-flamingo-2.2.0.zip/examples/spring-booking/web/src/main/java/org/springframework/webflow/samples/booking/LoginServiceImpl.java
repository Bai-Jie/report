package org.springframework.webflow.samples.booking;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.security.Authentication;
import org.springframework.security.AuthenticationTrustResolverImpl;
import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.event.authentication.AuthenticationSuccessEvent;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.web.context.ContextLoader;

/**
 * Class for security related services
 * @author aburak
 *
 */
@Service("loginService")
public class LoginServiceImpl implements LoginService, ApplicationListener {

    @Autowired
    UserService userService;
    
    /* (non-Javadoc)
     * @see org.springframework.webflow.samples.booking.LoginService#isLoggedIn()
     */
    public boolean isLoggedIn() {
	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	boolean authenticated = authentication != null && authentication.isAuthenticated();
	if (authenticated) {
	    return !(new AuthenticationTrustResolverImpl().isAnonymous(authentication));
	}
	
	return false;
    }

    /* (non-Javadoc)
     * @see org.springframework.context.ApplicationListener#onApplicationEvent(org.springframework.context.ApplicationEvent)
     */
    public void onApplicationEvent(ApplicationEvent event) {
	if (event instanceof AuthenticationSuccessEvent) {
	    User user = (User) ContextLoader.getCurrentWebApplicationContext().getBean("user");
	    if (user.getUsername() == null) {
		UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) event.getSource();
		String name = token.getName();
		
		User dbUser = userService.findUserByUsername(name);
		user.setId(dbUser.getId());
		user.setUsername(name);
		user.setPassword(dbUser.getPassword());
		user.setName(dbUser.getName());
	    }
	 } 
    }

}
