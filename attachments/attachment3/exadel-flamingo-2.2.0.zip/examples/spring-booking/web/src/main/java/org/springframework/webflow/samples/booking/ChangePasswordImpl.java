package org.springframework.webflow.samples.booking;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Updates user's password in database.
 *
 * @author apleskatsevich
 */
@Service("changePassword")
@Repository
public class ChangePasswordImpl implements ChangePassword {
	
	private static final String CHANGE_SUCCESSFUL = "successfulChanged";
	private static final String CHANGE_ERROR = "changeError";

	
    private EntityManager em;
    private String verifyPassword;
    
    @Autowired
    UserService userService;

    @PersistenceContext
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }

    /**
     * Updates password for particular user.
     * 
     * @param username Username
     * @param password New password to set
     */
    @Transactional
    public String changePassword(String username, String password) {
        if (verifyPassword != null && verifyPassword.equals(password)) {
            User user = userService.findUserByUsername(username);
            if (user != null) {
                user.setPassword(password);
                em.merge(user);
                return CHANGE_SUCCESSFUL;
            }
        }
        return CHANGE_ERROR;
    }

    public String getVerifyPassword() {
        return verifyPassword;
    }

    public void setVerifyPassword(String verifyPassword) {
        this.verifyPassword = verifyPassword;
    }
}
