package org.springframework.webflow.samples.booking;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;
import org.hibernate.validator.Pattern;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * A user who can book hotels.
 */
@Entity
@Component
@Scope("session")
@Table(name = "Customer")
public class User implements Serializable {

    private static final long serialVersionUID = -3652559447682574722L;
    
    private Integer id;
    
    private String username;

    private String password;

    private String name;

    public User() {
    }

    public User(String username, String password, String name) {
	this.username = username;
	this.password = password;
	this.name = name;
    }

    @Length(min = 4, max = 15)
    @Pattern(regex = "^\\w*$", message = "not a valid username")
    public String getUsername() {
	    return username;
    }

    public void setUsername(String username) {
	    this.username = username;
    }

    @NotNull
    @Length(min=5, max=15)
    public String getPassword() {
	    return password;
    }

    public void setPassword(String password) {
	    this.password = password;
    }

    @NotNull
    @Length(max=100)
    public String getName() {
	    return name;
    }

    public void setName(String name) {
	    this.name = name;
    }
    
    @Id @GeneratedValue
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    @Override
    public String toString() {
	return "User(" + username + ")";
    }
}
