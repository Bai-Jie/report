package org.springframework.webflow.samples.booking;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of UserService
 * 
 * @author klebed
 */
@Service("registerService")
@Repository
public class RegisterServiceImpl implements RegisterService {

    private static final String SUCCESSFUL_REGISTER = "successfulRegister";
    private static final String ERROR_USER_VALIDATION = "errorUserValidation";
    private static final String ALREADY_EXIST_USER_ERROR = "errorRegister";
    private String verifyPassword;
    private EntityManager em;

    @PersistenceContext
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }

    @Transactional
    public String saveUserAction(User user) {

        if (!isPasswordsFieldsEqual(user, verifyPassword)) {
            return ERROR_USER_VALIDATION;
        }

        if (saveUser(user)) {
            return SUCCESSFUL_REGISTER;
        }

        return ALREADY_EXIST_USER_ERROR;
    }

    private boolean isPasswordsFieldsEqual(User user, String verifyPassword) {
        return user.getPassword().equals(verifyPassword);
    }

    @Transactional
    public boolean saveUser(User user) {
        if (isSameUserExist(user)) {
            return false;
        }
        em.persist(user);
        return true;
    }

    @Transactional(readOnly = true)
    public boolean isSameUserExist(User user) {
        Query query = em.createQuery("select u from " + User.class.getCanonicalName() + " u where u.name = :name" + " and u.username = :username").setParameter("name", user.getName()).setParameter("username", user.getUsername());
        List resultList = query.getResultList(); 
        return resultList != null && !resultList.isEmpty();
    }

    public String getVerifyPassword() {
        return verifyPassword;
    }

    public void setVerifyPassword(String verifyPassword) {
        this.verifyPassword = verifyPassword;
    }
}
