package org.springframework.webflow.samples.booking;
/*
 * UserService.java		Date created: Jun 26, 2008
 * Last modified by: $Author: aburak $
 * $Revision: 1745 $	$Date: 2008-06-27 07:03:59 -0700 (Fri, 27 Jun 2008) $
 */

/**
 * A service interface to retrieve user information
 */
public interface UserService {

    User findUserByUsername(String username);
}
