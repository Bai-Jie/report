/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 *
 * Created on: 30-10-2009
 * $Revision: 2665 $
 * Last modified: $Author: skucherenosov $ $Date: 2010-05-13 02:17:06 -0700 (Thu, 13 May 2010) $
 */
package com.exadel.flamingo.samples.validation.android;

import java.util.List;

import com.exadel.flamingo.java.validator.simple.SimplePropertyValidator;
import com.exadel.flamingo.samples.android.Helper;
import com.exadel.flamingo.samples.android.ActionField;
import com.exadel.flamingo.samples.android.Label;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.exadel.flamingo.android.FlamingoApplication;
import com.exadel.flamingo.samples.android.FlamingoSamplesParentActivity;
import com.exadel.flamingo.samples.validation.android.R;

/**
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ValidationSampleActivity extends FlamingoSamplesParentActivity {

	private ActionField nameField;
	private Label messageInfo;
	private SimplePropertyValidator propertyValidator;
	//private TextView view;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		nameField = new ActionField(this, getString(R.string.nameLabel), getString(R.string.validationButton));
		nameField.getActionButton().setOnClickListener(new Button.OnClickListener() {

			public void onClick(View view) {
				validate();
			}
		});
		messageInfo = new Label(this, getString(R.string.messageInfoLabel));

		getContent().addView(nameField);
		getContent().addView(messageInfo);
		setContent(getContent());
	}

	@Override
	protected void factoryInitialized() {
		super.factoryInitialized();
		propertyValidator = ((FlamingoApplication)getApplication()).createAsynchronousPropertyValidator(nameField.getText(), "person", "lastName");
		propertyValidator.setRequired(true);
	}

	private void validate() {
		getContent().post(new Runnable() {

			public void run() {
				try {
					List<String> messages = propertyValidator.validate();
					if(messages!=null && messages.size() > 0){
						messageInfo.setText(messages.get(0));
					}else{
						messageInfo.setText("");
					}
				} catch (Exception exception) {
					viewException(exception);
				}
			}
		});
	}

	@Override
	protected String createUrl(String server, String implementation) {
		return server + '/' + implementation + "-validation/resource/hessian"; //used war seam-validation.war or spring-validation.war
	}
}
