/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

/**
 * @author abasharkevich
 *
 */
public interface ChangePassword {
	
	public void changePassword();
	public boolean isChanged();
	public String getVerify();
	public void setVerify(String verify);
	public void destroy();

}
