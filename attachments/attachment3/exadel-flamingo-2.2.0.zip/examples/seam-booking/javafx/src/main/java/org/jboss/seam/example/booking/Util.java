/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package org.jboss.seam.example.booking;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author abasharkevich
 * 
 */
public class Util {

	/**
	 * Method convert String to Date.
	 * 
	 * @param str
	 *            String to convert
	 * @return date
	 */
	public static Date convertStringToDate(String str) {
		Date date = new Date();
		try {
			date = new SimpleDateFormat("MM/dd/yyyy").parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	/**
	 * Method convert String to other String.
	 * 
	 * @param str
	 *            String to convert
	 * @return strOutDt String like "EEE, d MMM yyyy"
	 */
	public static String convertToAnotherFormat(String str) {
		Date dtTmp;
		String strOutDt = "test";
		if (str != "") {
			try {
				dtTmp = new SimpleDateFormat("MM/dd/yyyy").parse(str);
				strOutDt = new SimpleDateFormat("EEE, d MMM yyyy")
						.format(dtTmp);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return strOutDt;
	}

	/**
	 * Method convert Date to String.
	 * 
	 * @param date
	 *            Date to convert
	 * @return str like "EEE, d MMM yyyy"
	 */
	public static String convertDateToString(Date date) {
		String str = "";
		str = new SimpleDateFormat("EEE, d MMM yyyy").format(date);
		return str;
	}

	/**
	 * Method return current day.
	 * 
	 * @return curDay String like "MM/dd/yyyy"
	 */
	public static String getCurrentDay() {
		String curDay = "";
		Calendar calendar = Calendar.getInstance();
		Date day = calendar.getTime();
		curDay = new SimpleDateFormat("MM/dd/yyyy").format(day);
		return curDay;
	}

	/**
	 * Method return next day.
	 * 
	 * @return nextDay String like "MM/dd/yyyy"
	 */
	public static String getNextDay() {
		String nextDay = "";
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, +1);
		Date day = calendar.getTime();
		nextDay = new SimpleDateFormat("MM/dd/yyyy").format(day);
		return nextDay;
	}

	/**
	 * Method compare date and return message.
	 * 
	 * @return message
	 */
	public static String checkDateFailedMessage(String checkInDate,
			String checkOutDate) {
		Date firstDate = new Date();
		Date secondDate = new Date();
		Date dtCheckInDate;
		String checkInDateInOtherFormat = "";
		Date dtCheckOutDate;
		String checkOutDateInOtherFormat = "";
		String message = "";
		if ("".equals(checkInDate) || "".equals(checkOutDate)) {
			return message = "This field is required.";
		}
		try {
			dtCheckInDate = new SimpleDateFormat("MM/dd/yyyy")
					.parse(checkInDate);
			dtCheckOutDate = new SimpleDateFormat("MM/dd/yyyy")
					.parse(checkOutDate);
			try {
				checkInDateInOtherFormat = new SimpleDateFormat("yyyy-MM-dd")
						.format(dtCheckInDate);
				firstDate = new SimpleDateFormat("yyyy-MM-dd")
						.parse(checkInDateInOtherFormat);
				checkOutDateInOtherFormat = new SimpleDateFormat("yyyy-MM-dd")
						.format(dtCheckOutDate);
				secondDate = new SimpleDateFormat("yyyy-MM-dd")
						.parse(checkOutDateInOtherFormat);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_MONTH, -1);
			if (firstDate.before(calendar.getTime())) {
				message = "Check in date must be a future date.";
			} else if (!firstDate.before(secondDate)) {
				message = "Check out date must be later than check in date.";
			} else {
				message = "";
			}
		} catch (ParseException ex) {
			message = "Date must be in the format 'MM/dd/yyyy'.";
		}
		return message;
	}
}
