/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

/**
 * @author abasharkevich
 *
 */
public interface Identity {
	
	public void setUsername(String username);
	public void setPassword(String password);
	public String login();
	public boolean isLoggedIn();
	public void logout();

}
