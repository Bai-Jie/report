/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

/**
 * @author abasharkevich
 *
 */
public interface User {
	
	public void setName(String name);
	public void setPassword(String password);
    public void setUsername(String username);
    public String getName();

}
