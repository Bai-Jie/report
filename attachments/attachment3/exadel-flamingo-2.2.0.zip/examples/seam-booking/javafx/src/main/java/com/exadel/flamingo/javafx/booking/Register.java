/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

import javax.ejb.Local;

@Local
/**
 * @author abasharkevich
 *
 */
public interface Register {
	
	public void register();
	   public void invalid();
	   public String getVerify();
	   public void setVerify(String verify);
	   public boolean isRegistered();	   
	   public void destroy();

}
