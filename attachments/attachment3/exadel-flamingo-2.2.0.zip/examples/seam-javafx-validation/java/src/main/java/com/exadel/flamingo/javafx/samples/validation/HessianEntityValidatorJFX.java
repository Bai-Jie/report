/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.exadel.flamingo.javafx.samples.validation;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Observable;
import javax.swing.JComponent;
import javax.swing.text.JTextComponent;
import com.exadel.flamingo.java.FlamingoServiceFactory;

/**
 *
 * @author Sergey Rusak
 */
public class HessianEntityValidatorJFX extends Observable {
    private String returnedMessage;
    private Boolean required = false;    
    private Thread thread;    
    private JComponent source;
    private String destProp;

     /**
     * @param destination shown not be null
     * @param property should not be null
     * @param source should not be null
     * @throws IllegalArgumentException if any of the arguments is null
     */
    public HessianEntityValidatorJFX(String destination, String property,JComponent source){
        this(destination,property,source,false);
    }

     /**
     * @param destination shown not be null
     * @param property should not be null
     * @param source should not be null
     * @param required should not be null
     * @throws IllegalArgumentException if any of the arguments is null
     */
    public HessianEntityValidatorJFX(String destination, String property,JComponent source, Boolean required) {
        if (source==null || destination==null ||property==null || required==null)
            throw new IllegalArgumentException("Constructor arguments should not be null");
        this.destProp = new StringBuffer()
                .append(destination)
                .append(".")
                .append(property).toString();
        this.source = source;
        final HessianEntityValidatorJFX v = this;
        //register a focus listener which start separate thread on focus lost to
        //validate the input
        source.addFocusListener( new FocusListener(){
                public void focusLost(final FocusEvent e){                   
                   Runnable r = new Runnable(){                        
                        public void run(){                            
                            v.validate();
                        }
                    };
                    v.thread = new Thread(r);
                    v.thread.start();                   
                }
                public void focusGained(FocusEvent e){
                }
        });
    }

    public synchronized String getReturnedMessage() {
        return returnedMessage;
    }

    /**
    * Performs validation of value of component contained in <code>source</code>.
     * Returns message with validation error description if value is invalid or empty string if validation
     * passed successfully.
     */
    public synchronized String validate(){
        return doValidation( ((JTextComponent)source).getText());
    }
    
    /**
    * Executes validation call to the server. Returns empty string if passed value is valid.
     *
     * @param value Validated value
     * @return Validation message
     */
    private String doValidation(String value){
        if (!required && "".equals(value)) {
            returnedMessage = "";
        } else {
            returnedMessage = FlamingoServiceFactory.getHessianEntityValidator()
                    .validate(destProp, value);
        }        
        startNotification();
        return returnedMessage;
    }
    /*
     * notify observers
     */
    private void startNotification() {
         setChanged();
         notifyObservers();
     }
}
