/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */

package com.exadel.flamingo.javafx.samples;

import org.hibernate.validator.Length;
import org.jboss.seam.annotations.Name;

@Name("person")
public class PersonBean {

    private String lastName;

    /**
     * @return the lastName
     */
    @Length(min=3, max=40)
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
}
