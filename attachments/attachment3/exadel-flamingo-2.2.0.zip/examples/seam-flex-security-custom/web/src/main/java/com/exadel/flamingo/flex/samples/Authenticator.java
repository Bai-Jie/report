/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo.flex.samples;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.security.Identity;

@Name("authenticator")
public class Authenticator {
    public boolean authenticate() {
        String username = Identity.instance().getUsername();
        String password = Identity.instance().getPassword();
        if (username != null
            && password != null
            && username.equals(password)) {
            Identity.instance().addRole(username);
            return true;
        } else {
            return false;
        }
    }
}
