/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo.flex.samples;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.security.Restrict;

@Scope(ScopeType.STATELESS)
@Name("helloAction")
public class HelloAction {

    @Restrict("#{s:hasRole('admin')}")
    public String hello(String name) {
        return "Secure Hello, " + name;
    }

    public void process() {
        
    }
}
