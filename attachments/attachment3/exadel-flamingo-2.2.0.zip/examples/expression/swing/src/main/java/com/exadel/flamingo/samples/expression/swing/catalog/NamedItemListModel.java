/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 27-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.swing.catalog;

import com.exadel.flamingo.samples.swing.SimpleListModel;
import com.exadel.flamingo.samples.expression.catalog.NamedItem;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class NamedItemListModel extends SimpleListModel<NamedItem> {

	@Override
	public Object getElementAt(int index) {
		NamedItem item = getElement(index);
		if (item != null) {
			return item.getName();
		} else {
			return super.getElementAt(index);
		}
	}
}
