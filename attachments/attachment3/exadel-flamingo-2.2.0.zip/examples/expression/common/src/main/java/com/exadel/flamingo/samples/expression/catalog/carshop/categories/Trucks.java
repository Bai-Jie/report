/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 23-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.catalog.carshop.categories;

import com.exadel.flamingo.samples.expression.catalog.carshop.Truck;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class Trucks extends AbstractCategory {

	public Trucks() {
		super("Trucks", "This category contains trucks", Truck.class);
		Truck truck = new Truck();
		truck.setColor("Cyan Metallic");
		truck.setDescription("The Actros offers cost-efficient long distance transport solutions for virtually all applications. Building on the tried-and-trusted engineering of the previous Actros, extensive improvements and refinements have been made and an all-new driver-friendly cab interior takes comfort to new levels.");
		truck.setModel("Car Transporter Rigid 4x2 1836L");
		truck.setPrice(230.34);
		truck.setTonnage(18);
		add(truck);
	}
}
