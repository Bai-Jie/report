/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 23-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.catalog.carshop.categories;

import com.exadel.flamingo.samples.expression.catalog.carshop.Car;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class PassengerCars extends AbstractCategory {

	public PassengerCars() {
		super("Cars", "This category contains passengers cars", Car.class);
		Car car = new Car();
		car.setModel("Audi A8");
		car.setDescription("Audi's flagship A8 full-size luxury sedan is available in regular- and long-wheelbase (A8 L) form. It competes with the BMW 7 Series, Lexus LS 460 and Mercedes-Benz S-Class. The standard V-8 makes 350 horsepower, and an A8 L W12 sedan with a 450-hp W-12 engine is available");
		car.setColor("Quartz Gray Metallic");
		car.setPrice(74.050);
		add(car);

		car = new Car();
		car.setModel("Bentley Arnage");
		car.setDescription("After 10 years, Bentley's flagship Arnage is in its final year. For the first half of 2009, the Arnage comes in traditional trim levels of base R, extended-length RL and sporty T. Then, in the middle of 2009, just one trim level will be offered: the Arnage Final Series. The Arnage Final Series combines the performance of last year's Arnage T with the luxury and refinement of the Arnage R.");
		car.setColor("Gray Violet");
		car.setPrice(224.990);
		add(car);

		car = new Car();
		car.setModel("BMW 750");
		car.setDescription("BMW's flagship 7 Series is a full-size luxury sedan that competes with top-line sedans like the Audi A8, Jaguar XJ and Mercedes-Benz S-Class. The 7 Series comes in regular and extended wheelbases as the 750i and 750Li, respectively.");
		car.setColor("Imperial Blue Metallic");
		car.setPrice(80.300);
		add(car);

		car = new Car();
		car.setModel("Volvo V50");
		car.setDescription("Volvo's small wagon, the V50, comes in 2.4i and T5 trim levels, the latter of which is only available with all-wheel drive. Competitors include the Audi A4 Avant, Subaru Impreza Outback Sport and Volkswagen Jetta SportWagen.");
		car.setColor("Ice White");
		car.setPrice(29.800);
		add(car);

		car = new Car();
		car.setModel("Volvo V50");
		car.setDescription("Volvo's small wagon, the V50, comes in 2.4i and T5 trim levels, the latter of which is only available with all-wheel drive. Competitors include the Audi A4 Avant, Subaru Impreza Outback Sport and Volkswagen Jetta SportWagen.");
		car.setColor("Brilliant Blue Metallic");
		car.setPrice(30.120);
		add(car);

		car = new Car();
		car.setModel("Volvo V50");
		car.setDescription("Volvo's small wagon, the V50, comes in 2.4i and T5 trim levels, the latter of which is only available with all-wheel drive. Competitors include the Audi A4 Avant, Subaru Impreza Outback Sport and Volkswagen Jetta SportWagen.");
		car.setColor("Titanium Gray Metallic");
		car.setPrice(35.500);
		add(car);
	}
}
