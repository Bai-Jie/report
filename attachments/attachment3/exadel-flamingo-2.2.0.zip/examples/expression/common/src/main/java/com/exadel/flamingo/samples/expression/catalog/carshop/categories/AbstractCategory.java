/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 23-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.catalog.carshop.categories;

import com.exadel.flamingo.samples.expression.catalog.Category;
import com.exadel.flamingo.samples.expression.catalog.Product;
import java.util.Enumeration;
import java.util.Vector;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public abstract class AbstractCategory implements Category {

	private String name;
	private String description;
	private Class productType;
	private Vector productTypes = new Vector();

	public AbstractCategory(String name, String description, Class productType) {
		setName(name);
		setDescription(description);
		this.productType = productType;
	}

	public synchronized Product[] getProducts() {
		Product[] products = new Product[productTypes.size()];
		int index = 0;
		for (Enumeration productEnumeration = productTypes.elements(); productEnumeration.hasMoreElements();) {
			products[index++] = (Product) productEnumeration.nextElement();
		}
		return products;
	}

	public synchronized void add(Product product) {
		if (product != null) {
			if (productType.isAssignableFrom(product.getClass())) {
				productTypes.addElement(product);
			}
		}
	}

	public synchronized void remove(Product product) {
		productTypes.removeElement(product);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Vector getProductTypes() {
		return productTypes;
	}

	public void setProductTypes(Vector productTypes) {
		this.productTypes = productTypes;
	}
}
