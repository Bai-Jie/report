/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 *
 * Created on: 23-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.catalog.carshop;

import com.exadel.flamingo.samples.expression.catalog.Registry;
import com.exadel.flamingo.samples.expression.catalog.Category;
import com.exadel.flamingo.samples.expression.catalog.carshop.categories.Buses;
import com.exadel.flamingo.samples.expression.catalog.carshop.categories.PassengerCars;
import com.exadel.flamingo.samples.expression.catalog.carshop.categories.Trucks;
import java.util.Enumeration;
import java.util.Vector;

/**
 *
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class CarsRegistry implements Registry {

	private Vector categoryTypes = new Vector(3);

	public CarsRegistry() {
		categoryTypes.add(new PassengerCars());
		categoryTypes.add(new Buses());
		categoryTypes.add(new Trucks());
	}

	public Category[] getCategorys() {
		Category[] categorys = new Category[categoryTypes.size()];
		int index = 0;
		for (Enumeration categoryEnumeration = categoryTypes.elements(); categoryEnumeration.hasMoreElements();) {
			categorys[index++] = (Category) categoryEnumeration.nextElement();
		}
		return categorys;
	}
}
