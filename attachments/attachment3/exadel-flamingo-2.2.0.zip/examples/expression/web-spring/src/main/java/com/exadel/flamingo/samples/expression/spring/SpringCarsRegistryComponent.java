/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 26-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.spring;

import com.exadel.flamingo.samples.expression.catalog.carshop.CarsRegistry;
import org.springframework.stereotype.Service;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
@Service(CarsRegistry.NAME)
public class SpringCarsRegistryComponent extends CarsRegistry {
}
