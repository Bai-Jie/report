/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 *
 * Created on: 14-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.mobile.catalog;

import com.exadel.flamingo.samples.expression.mobile.catalog.io.ProductCatalogFlamingoHessianInput;
import com.exadel.flamingo.samples.expression.mobile.catalog.io.ProductCatalogFlamingoHessianOutput;
import com.exadel.flamingo.samples.expression.catalog.Category;
import com.exadel.flamingo.samples.expression.catalog.NamedItem;
import com.exadel.flamingo.samples.expression.catalog.Product;
import com.exadel.flamingo.samples.expression.catalog.RegistryService;
import com.exadel.flamingo.samples.expression.catalog.carshop.Bus;
import com.exadel.flamingo.samples.expression.catalog.carshop.Car;
import com.exadel.flamingo.samples.expression.catalog.carshop.Truck;
import com.exadel.flamingo.samples.expression.mobile.ExpressionSamplesParentMIDlet;
import com.exadel.flamingo.service.microedition.FlamingoServiceFactory;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;

/**
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ProductCatalogSampleMIDlet extends ExpressionSamplesParentMIDlet implements CommandListener {

	private RegistryService carRegistryService;
	private List categorysForm;
	private int categoryIndex = -1;
	private List productsForm;

	/**
	 * The ProductCatalogSampleMIDlet constructor.
	 */
	public ProductCatalogSampleMIDlet() {
		FlamingoServiceFactory.setHessianInputDecoratorClass(ProductCatalogFlamingoHessianInput.class);
		FlamingoServiceFactory.setHessianOutputDecoratorClass(ProductCatalogFlamingoHessianOutput.class);
	}

	protected void factoryInitialized() {
		super.factoryInitialized();
		carRegistryService = new RegistryService() {

			protected Object executeExpression(String expression) {
				return FlamingoServiceFactory.getInstance().getExpressionService().getValue(expression);
			}

			public Category[] getCategorys() {
				return (Category[]) executeExpression(createGetCategorysEL());
			}
		};
	}

	protected Displayable getContentForm() {
		return getCategorysForm();
	}

	public void commandAction(Command command, Displayable displayable) {
		if (displayable == categorysForm) {
			if (command == List.SELECT_COMMAND) {
				categoryIndex = getCategorysForm().getSelectedIndex();
				viewProducts();
			}
		} else {
			if (displayable == productsForm) {
				if (command == List.SELECT_COMMAND) {
					Product product = carRegistryService.getSelectedProduct(categoryIndex, getProductsForm(categoryIndex).getSelectedIndex());
					switchDisplayable(null, getProductInformationForm(product));
				} else {
					if (command == getBackCommand()) {
						switchDisplayable(null, getCategorysForm());
					}
				}
			} else {
				if (command == getBackCommand()) {
					viewProducts();
				}
			}
		}
		super.commandAction(command, displayable);
	}

	private List getCategorysForm() {
		if (categorysForm == null) {
			categorysForm = createList("Categories", carRegistryService.getCategorys());
			categorysForm.addCommand(getExitCommand());
			productsForm = null;
		}
		return categorysForm;
	}

	private List getProductsForm(int categoryIndex) {
		if (productsForm == null) {
			productsForm = createList("Products", carRegistryService.getSelectedCategory(categoryIndex).getProducts());
			productsForm.addCommand(getBackCommand());
		}
		return productsForm;
	}

	private List createList(String title, NamedItem[] items) {
		List list = new List(title, Choice.IMPLICIT);
		list.setCommandListener(this);
		list.setFitPolicy(Choice.TEXT_WRAP_DEFAULT);
		if (items != null) {
			for (int i = 0; i < items.length; i++) {
				list.append(items[i].getName(), null);
			}
		}
		return list;
	}

	private Form getProductInformationForm(Product product) {
		Form form = new Form(product.getName());
		form.setCommandListener(this);
		form.addCommand(getBackCommand());
		form.addCommand(getExitCommand());
		if (product instanceof Car) {
			Car car = (Car) product;
			form.append(new StringItem("Model", car.getModel()));
			form.append(new StringItem("Description", car.getDescription()));
			form.append(new StringItem("Color", car.getColor()));
			form.append(new StringItem("Price", String.valueOf(car.getPrice())));
		}
		if (product instanceof Bus) {
			Bus bus = (Bus) product;
			form.append(new StringItem("Seats", String.valueOf(bus.getPassengersSeats())));
		}
		if (product instanceof Truck) {
			Truck truck = (Truck) product;
			form.append(new StringItem("Tonnage", String.valueOf(truck.getTonnage())));
		}
		return form;
	}

	private void viewProducts() {
		productsForm = null;
		switchDisplayable(null, getProductsForm(categoryIndex));
	}
}
