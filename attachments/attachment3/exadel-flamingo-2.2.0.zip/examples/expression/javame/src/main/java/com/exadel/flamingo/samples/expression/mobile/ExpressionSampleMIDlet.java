/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 *
 * Created on: 14-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.mobile;

import com.exadel.flamingo.service.microedition.FlamingoServiceFactory;
import com.exadel.flamingo.service.microedition.service.ExpressionService;
import javax.microedition.lcdui.*;

/**
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ExpressionSampleMIDlet extends ExpressionSamplesParentMIDlet {

	private volatile boolean promptTimeFromServer = true;
	private Thread serverTimeThread;
	private volatile ExpressionService service;
	private Form mainForm;
	private StringItem lastAccessTimeLabel;
	private StringItem serverSaysLabel;
	private StringItem serverTimeLabel;
	private TextField nameField;
	private Spacer spacer;
	private Command sendNameCommand;

	/**
	 * The ExpressionSampleMIDlet constructor.
	 */
	public ExpressionSampleMIDlet() {
	}

	protected void factoryInitialized() {
		super.factoryInitialized();
		service = FlamingoServiceFactory.getInstance().getExpressionService();
	}

	/**
	 * Initilizes the application.
	 * It is called only once when the MIDlet is started. The method is called before the <code>startMIDlet</code> method.
	 */
	protected void initialize() {
		serverTimeThread = new Thread(new Runnable() {

			public void run() {
				while (serverTimeThread.isAlive() && promptTimeFromServer) {
					try {
						updateCurrentTime();
						Thread.sleep(1000);
					} catch (InterruptedException exception) {
						exception.printStackTrace();
						promptTimeFromServer = false;
					}
				}
			}
		});
		serverTimeThread.start();
	}

	protected Displayable getContentForm() {
		if (mainForm == null) {
			mainForm = new Form("Expression Sample", new Item[]{getNameField(), getServerSaysLabel(), getLastAccessTimeLabel(), getSpacer(), getServerTimeLabel()});
			mainForm.addCommand(getExitCommand());
			mainForm.setCommandListener(this);
		}
		return mainForm;
	}

	/**
	 * Returns an initiliazed instance of serverSaysLabel component.
	 * @return the initialized component instance
	 */
	public StringItem getServerSaysLabel() {
		if (serverSaysLabel == null) {
			serverSaysLabel = new StringItem("Server says:", null);
		}
		return serverSaysLabel;
	}

	/**
	 * Returns an initiliazed instance of lastAccessTimeLabel component.
	 * @return the initialized component instance
	 */
	public StringItem getLastAccessTimeLabel() {
		if (lastAccessTimeLabel == null) {
			lastAccessTimeLabel = new StringItem("Last access time:", null);
		}
		return lastAccessTimeLabel;
	}

	/**
	 * Returns an initiliazed instance of serverTimeLabel component.
	 * @return the initialized component instance
	 */
	public StringItem getServerTimeLabel() {
		if (serverTimeLabel == null) {
			serverTimeLabel = new StringItem("Current server time:", null);
		}
		return serverTimeLabel;
	}

	/**
	 * Performs an action assigned to the sayHello entry-point.
	 */
	public void sayHello() {
		new Thread(new Runnable() {

			public void run() {
				try {
					if (service != null) {
						Class[] types = new Class[]{
							String.class
						};
						Object[] parameters = new Object[]{
							getNameField().getString()
						};
						getServerSaysLabel().setText(String.valueOf(service.invokeMethod("serverAction.sayHello", String.class, types, parameters)));
						getLastAccessTimeLabel().setText(String.valueOf(service.getValue("serverAction.lastAccessTime")));
					}
				} catch (Exception exception) {
					viewException(exception);
				}
			}
		}).start();
	}

	/**
	 * Performs an action assigned to the updateCurrentTime entry-point.
	 */
	public void updateCurrentTime() {
		new Thread(new Runnable() {

			public void run() {
				try {
					if (service != null) {
						getServerTimeLabel().setText(String.valueOf(service.getValue("serverAction.currentTime")));
					}
				} catch (RuntimeException exception) {
					viewException(exception);
				}
			}
		}).start();
	}

	/**
	 * Returns an initiliazed instance of nameField component.
	 * @return the initialized component instance
	 */
	public TextField getNameField() {
		if (nameField == null) {
			nameField = new TextField("Enter name", null, 32, TextField.ANY);
			nameField.addCommand(getSendNameCommand());
			nameField.setItemCommandListener(this);
			nameField.setDefaultCommand(getSendNameCommand());
		}
		return nameField;
	}

	/**
	 * Returns an initiliazed instance of spacer component.
	 * @return the initialized component instance
	 */
	public Spacer getSpacer() {
		if (spacer == null) {
			spacer = new Spacer(16, 1);
		}
		return spacer;
	}

	/**
	 * Called by a system to indicated that a command has been invoked on a particular item.
	 * @param command the Command that was invoked
	 * @param displayable the Item where the command was invoked
	 */
	public void commandAction(Command command, Item item) {
		if (item == nameField) {
			if (command == sendNameCommand) {
				sayHello();
			}
		}
		super.commandAction(command, item);
	}

	/**
	 * Returns an initiliazed instance of sendNameCommand component.
	 * @return the initialized component instance
	 */
	public Command getSendNameCommand() {
		if (sendNameCommand == null) {
			sendNameCommand = new Command("Say Hello", Command.OK, 0);
		}
		return sendNameCommand;
	}

	/**
	 * Called to signal the MIDlet to terminate.
	 * @param unconditional if true, then the MIDlet has to be unconditionally terminated and all resources has to be released.
	 */
	public void destroyApp(boolean unconditional) {
		promptTimeFromServer = false;
	}
}
