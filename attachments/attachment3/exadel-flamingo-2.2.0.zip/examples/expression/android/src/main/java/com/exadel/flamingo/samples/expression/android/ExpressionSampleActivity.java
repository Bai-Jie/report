/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 *
 * Created on: 30-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.android;

import com.exadel.flamingo.samples.android.Helper;
import com.exadel.flamingo.samples.android.ActionField;
import com.exadel.flamingo.samples.android.Label;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.exadel.flamingo.expression.ExpressionService;

/**
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ExpressionSampleActivity extends ExpressionSamplesParentActivity {

	private ActionField nameField;
	private Label serverSays;
	private Label lastAccessTime;
	private Label serverTime;
	private volatile boolean promptTimeFromServer = true;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		nameField = new ActionField(this, getString(R.string.nameLabel), getString(R.string.nameButton));
		nameField.getActionButton().setOnClickListener(new Button.OnClickListener() {

			public void onClick(View view) {
				String name = Helper.getString(nameField);
				sayHello(name);
			}
		});
		serverSays = new Label(this, getString(R.string.serverSaysLabel));
		lastAccessTime = new Label(this, getString(R.string.lastAccessTimeLabel));
		serverTime = new Label(this, getString(R.string.serverTimeLabel));

		getContent().addView(nameField);
		getContent().addView(serverSays);
		getContent().addView(lastAccessTime);
		getContent().addView(serverTime);
		setContent(getContent());
	}

	@Override
	protected void onStart() {
		super.onStart();
		new Thread(new Runnable() {

			public void run() {
				while (promptTimeFromServer) {
					try {
						updateCurrentTime();
						Thread.sleep(1000);
					} catch (InterruptedException exception) {
						viewException(exception);
						promptTimeFromServer = false;
					}
				}
			}
		}).start();
	}

	@Override
	protected void onPause() {
		promptTimeFromServer = false;
		super.onPause();
	}

	private void updateCurrentTime() {
		getContent().post(new Runnable() {

			public void run() {
				try {
					ExpressionService service = getService();
					if (service != null) {
						serverTime.setText(String.valueOf(service.getValue("serverAction.currentTime")));
					}
				} catch (RuntimeException exception) {
					viewException(exception);
				}
			}
		});
	}

	private void sayHello(final String name) {
		getContent().post(new Runnable() {

			public void run() {
				try {
					ExpressionService service = getService();
					if (service != null) {
						Class[] types = new Class[]{
							String.class
						};
						Object[] parameters = new Object[]{
							name
						};
						serverSays.setText(String.valueOf(service.invokeMethod("serverAction.sayHello", String.class, types, parameters)));
						lastAccessTime.setText(String.valueOf(service.getValue("serverAction.lastAccessTime")));
					}
				} catch (Exception exception) {
					viewException(exception);
				}
			}
		});
	}
}
