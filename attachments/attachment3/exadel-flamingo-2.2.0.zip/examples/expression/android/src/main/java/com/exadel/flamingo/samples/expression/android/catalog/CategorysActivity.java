/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.android.catalog;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListView;
import com.exadel.flamingo.samples.expression.catalog.Category;
import com.exadel.flamingo.samples.expression.catalog.RegistryService;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class CategorysActivity extends NamedItemListActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		RegistryService carRegistryService = getCarRegistryService();
		for (Category category : carRegistryService.getCategorys()) {
			getNamedItemsAdapter().add(category);
		}
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		Intent intent = new Intent(this, ProductsActivity.class);
		intent.putExtra(ProductsActivity.CATEGORY_INDEX, position);
		startActivity(intent);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent();
			intent.putExtra(ProductCatalogSample.CLOSE_APPLICATION, true);
			setResult(RESULT_OK, intent);
		}
		return super.onKeyDown(keyCode, event);
	}
}
