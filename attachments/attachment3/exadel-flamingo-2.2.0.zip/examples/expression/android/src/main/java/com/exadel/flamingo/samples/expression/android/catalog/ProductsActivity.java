/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.android.catalog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import com.exadel.flamingo.samples.expression.catalog.Category;
import com.exadel.flamingo.samples.expression.catalog.Product;
import com.exadel.flamingo.samples.expression.catalog.RegistryService;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ProductsActivity extends NamedItemListActivity {

	public static final String CATEGORY_INDEX = "categoryIndex";
	private int categoryIndex;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		RegistryService carRegistryService = getCarRegistryService();
		categoryIndex = getIntent().getIntExtra(CATEGORY_INDEX, -1);
		Category category = carRegistryService.getSelectedCategory(categoryIndex);
		for (Product product : category.getProducts()) {
			getNamedItemsAdapter().add(product);
		}
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		Intent intent = new Intent(this, ProductInformationActivity.class);
		intent.putExtra(ProductInformationActivity.CATEGORY_INDEX, categoryIndex);
		intent.putExtra(ProductInformationActivity.PRODUCT_INDEX, position);
		startActivity(intent);
	}
}
