/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.android.catalog;

import android.content.Intent;
import com.exadel.flamingo.samples.expression.android.ExpressionSamplesParentActivity;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ProductCatalogSample extends ExpressionSamplesParentActivity {

	public static final String CLOSE_APPLICATION = "closeApplication";

	@Override
	protected void factoryInitialized() {
		super.factoryInitialized();
		startActivityForResult(new Intent(this, CategorysActivity.class), RESULT_FIRST_USER);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (data.getBooleanExtra(CLOSE_APPLICATION, false)) {
			finish();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}
