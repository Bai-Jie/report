/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author apleskatsevich
 */
public class Department {

    private String name;

    private PersonBean manager;

    private List<PersonBean> staff = new ArrayList<PersonBean>();

    public PersonBean getManager() {
        return manager;
    }

    public void setManager(PersonBean manager) {
        this.manager = manager;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List getStaff() {
        return staff;
    }

    public void setStaff(List staff) {
        this.staff = staff;
    }
}
