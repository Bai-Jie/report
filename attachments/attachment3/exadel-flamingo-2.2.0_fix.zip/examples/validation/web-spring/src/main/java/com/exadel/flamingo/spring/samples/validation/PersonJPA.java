/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo.spring.samples.validation;


import javax.persistence.Entity;

import org.hibernate.validator.Length;

@Entity(name="person")
public class PersonJPA {

    private String lastName;

    /**
     * @return the lastName
     */
    @Length(min=3, max=40)
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
}
