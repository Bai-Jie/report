INSTRUCTIONS

1.	In order to build the Android UI, you must perform the following steps:

	1.1	Install Android SDK and Android Platform 1.6 (http://developer.android.com/sdk/index.html)

	1.2	Set environment variable ANDROID_HOME to path where you are installed Android

	1.3	Build example by command "mvn clean install"

	1.4	Deploy war (seam/spring) files to server

	1.5	To run Android example you should execute Android-emulator and deploy example to it by command
		"mvn com.jayway.maven.plugins.android.generation2:maven-android-plugin:deploy" in "android" folder

	1.6	You will need to specify the IP address of the server on which you deploy this example. If you run the server
		locally and you don't know your IP address, you can get it for example with the following command
		"sudo ifconfig eth0" under Linux or "ipconfig" under Windows