/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-10-2009
 * $Revision: 2663 $
 * Last modified: $Author: skucherenosov $ $Date: 2010-05-12 07:33:52 -0700 (Wed, 12 May 2010) $
 */
package com.exadel.flamingo.samples.android;

import android.content.Context;
import android.widget.TextView;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class Label extends TextView {

	private String staticPart;

	public Label(Context context, String staticPart) {
		super(context);
		this.staticPart = staticPart;
		setText("");
	}

	@Override
	public void setText(CharSequence text, BufferType type) {
		super.setText(staticPart + text, type);
	}
}
