/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 03-11-2009
 * $Revision: 2663 $
 * Last modified: $Author: skucherenosov $ $Date: 2010-05-12 07:33:52 -0700 (Wed, 12 May 2010) $
 */
package com.exadel.flamingo.samples.android;

import android.text.Editable;
import android.view.ViewGroup;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class Helper {

	private Helper() {
	}

	public static void setEnabledForChilds(ViewGroup parent) {
		if (parent != null) {
			boolean enabled = parent.isEnabled();
			int childCount = parent.getChildCount();
			for (int i = 0; i < childCount; i++) {
				parent.getChildAt(i).setEnabled(enabled);
			}
		}
	}

	public static String getString(Editable editable) {
		String returnValue = "";
		if (editable != null) {
			returnValue = String.valueOf(editable.subSequence(0, editable.length()));
		}

		return returnValue;
	}

	public static String getString(ActionField actionField) {
		return getString(actionField.getText().getText());
	}
}
