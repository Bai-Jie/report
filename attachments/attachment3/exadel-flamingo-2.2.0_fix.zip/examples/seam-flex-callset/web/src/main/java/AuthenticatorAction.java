
/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

import static org.jboss.seam.ScopeType.SESSION;


import org.jboss.seam.annotations.Name;
import org.jboss.seam.security.Identity;

@Name("authenticator")
public class AuthenticatorAction {

    public boolean authenticate() {
        if ("admin".equals(Identity.instance().getUsername())) {
            return "qwerty".equals(Identity.instance().getPassword());
        } else if ("user".equals(Identity.instance().getUsername())) {
            return "123456".equals(Identity.instance().getPassword());
        }

        return false;

    }
}
