/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo.spring.samples.calculator;

public class CalculatorService {

    private int value;
    
    public int add(int extra) {
    	value += extra;
        return value;
    }

    public void clear() {
    	value = 0;
    }
}
