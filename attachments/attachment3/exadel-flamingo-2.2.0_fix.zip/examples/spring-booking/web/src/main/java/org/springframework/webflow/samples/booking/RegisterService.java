package org.springframework.webflow.samples.booking;

/**
 * Interface for saving new user
 * 
 * @author klebed
 *
 */
interface RegisterService {

    /**
     * Provide saving new user
     * @param user - instance of User class
     * @param verifyPassword - verify password string
     * @return true if user was successful saved, otherwise false
     */
    public String saveUserAction(User user);

    public String getVerifyPassword();

    public void setVerifyPassword(String verifyPassword);
}
