/*
 * UserServiceImpl.java		Date created: Jun 26, 2008
 * Last modified by: $Author: aburak $
 * $Revision: 1745 $	$Date: 2008-06-27 07:03:59 -0700 (Fri, 27 Jun 2008) $
 */

package org.springframework.webflow.samples.booking;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * JPA implementation of UserService
 */

@Service("userService")
@Repository
public class UserServiceImpl implements UserService {

    private EntityManager em;

    @PersistenceContext
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }    
    
    @Transactional(readOnly = true)
    public User findUserByUsername(String username) {
        return (User) em.createQuery("select u from User u where u.username = :username").setParameter("username",
                username).getSingleResult();
    }

}
