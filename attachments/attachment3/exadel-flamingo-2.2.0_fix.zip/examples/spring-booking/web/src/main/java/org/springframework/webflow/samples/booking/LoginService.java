package org.springframework.webflow.samples.booking;

/**
 * Interface for security related service
 * @author aburak
 *
 */
public interface LoginService {

    /**
     * Check whether user has logged in to current session
     * @return boolean
     */
    boolean isLoggedIn();
}
