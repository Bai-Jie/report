/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

/**
 * @author abasharkevich
 * 
 */
public interface BindingManager {

	public String commit(String componentName, Object value);

	public Object getObject(String name);

}
