/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package org.jboss.seam.example.booking;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author abasharkevich
 * 
 */
public class Booking implements Serializable {

	private Long id;
	private User user;
	private Hotel hotel;
	private Date checkinDate;
	private Date checkoutDate;
	private String creditCard;
	private String creditCardName;
	private int creditCardExpiryMonth;
	private int creditCardExpiryYear;
	private boolean smoking;
	private int beds;

	/**
	 * Method return total price for all day.
	 * 
	 * @return total price
	 */
	public BigDecimal getTotal() {
		return hotel.getPrice().multiply(new BigDecimal(getNights()));
	}

	/**
	 * Method return number of day.
	 * 
	 * @return number of day
	 */
	public int getNights() {
		return (int) (checkoutDate.getTime() - checkinDate.getTime()) / 1000
				/ 60 / 60 / 24;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return the hotel
	 */
	public Hotel getHotel() {
		return hotel;
	}

	/**
	 * @param hotel
	 *            the hotel to set
	 */
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	/**
	 * @return the checkinDate
	 */
	public Date getCheckinDate() {
		return checkinDate;
	}

	/**
	 * @param checkinDate
	 *            the checkinDate to set
	 */
	public void setCheckinDate(Date checkinDate) {
		this.checkinDate = checkinDate;
	}

	/**
	 * @return the checkoutDate
	 */
	public Date getCheckoutDate() {
		return checkoutDate;
	}

	/**
	 * @param checkoutDate
	 *            the checkoutDate to set
	 */
	public void setCheckoutDate(Date checkoutDate) {
		this.checkoutDate = checkoutDate;
	}

	/**
	 * @return the creditCard
	 */
	public String getCreditCard() {
		return creditCard;
	}

	/**
	 * @param creditCard
	 *            the creditCard to set
	 */
	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}

	/**
	 * @return the creditCardName
	 */
	public String getCreditCardName() {
		return creditCardName;
	}

	/**
	 * @param creditCardName
	 *            the creditCardName to set
	 */
	public void setCreditCardName(String creditCardName) {
		this.creditCardName = creditCardName;
	}

	/**
	 * @return the creditCardExpiryMonth
	 */
	public int getCreditCardExpiryMonth() {
		return creditCardExpiryMonth;
	}

	/**
	 * @param creditCardExpiryMonth
	 *            the creditCardExpiryMonth to set
	 */
	public void setCreditCardExpiryMonth(int creditCardExpiryMonth) {
		this.creditCardExpiryMonth = creditCardExpiryMonth;
	}

	/**
	 * @return the creditCardExpiryYear
	 */
	public int getCreditCardExpiryYear() {
		return creditCardExpiryYear;
	}

	/**
	 * @param creditCardExpiryYear
	 *            the creditCardExpiryYear to set
	 */
	public void setCreditCardExpiryYear(int creditCardExpiryYear) {
		this.creditCardExpiryYear = creditCardExpiryYear;
	}

	/**
	 * @return the smoking
	 */
	public boolean isSmoking() {
		return smoking;
	}

	/**
	 * @param smoking
	 *            the smoking to set
	 */
	public void setSmoking(boolean smoking) {
		this.smoking = smoking;
	}

	/**
	 * @return the beds
	 */
	public int getBeds() {
		return beds;
	}

	/**
	 * @param beds
	 *            the beds to set
	 */
	public void setBeds(int beds) {
		this.beds = beds;
	}

}
