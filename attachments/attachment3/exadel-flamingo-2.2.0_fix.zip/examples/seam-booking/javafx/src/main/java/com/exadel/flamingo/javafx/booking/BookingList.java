/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

import org.jboss.seam.example.booking.Booking;

/**
 * @author abasharkevich
 *
 */
public interface BookingList {

	public void cancel(Booking bookingToCancel);

}
