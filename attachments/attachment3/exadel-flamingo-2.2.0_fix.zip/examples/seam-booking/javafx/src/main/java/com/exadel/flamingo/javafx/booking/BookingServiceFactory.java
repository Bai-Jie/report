/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

import java.util.List;

import org.jboss.seam.example.booking.Booking;
import org.jboss.seam.example.booking.Hotel;

import com.exadel.flamingo.java.ServiceFactory;

/**
 * @author abasharkevich
 * 
 */
public class BookingServiceFactory {

	/**
	 * Method return User.class.
	 * 
	 * @return User
	 */
	public static User getUser() {
		return (User) ServiceFactory.getInstance().getService(User.class, "user");
	}

	/**
	 * Method return Register.class.
	 * 
	 * @return Register
	 */
	public static Register getRegister() {
		return (Register) ServiceFactory.getInstance().getService(Register.class, "register");
	}

	/**
	 * Method return Identity.class.
	 * 
	 * @return Identity
	 */
	public static Identity getIdentity() {
		return (Identity) ServiceFactory.getInstance().getService(Identity.class,
				"org.jboss.seam.security.identity");
	}

	/**
	 * Method return ChangePassword.class.
	 * 
	 * @return ChangePassword
	 */
	public static ChangePassword getChangePassword() {
		return (ChangePassword) ServiceFactory.getInstance().getService(ChangePassword.class,
				"changePassword");
	}

	/**
	 * Method return BindingManager.class.
	 * 
	 * @return BindingManager
	 */
	public static BindingManager getBindingManager() {
		return (BindingManager) ServiceFactory.getInstance().getService(BindingManager.class,
				"com.exadel.flamingo.service.binding.bindingManager");
	}

	/**
	 * Method return HotelSearching.class.
	 * 
	 * @return HotelSearching
	 */
	public static HotelSearching getHotelSearching() {
		return (HotelSearching) ServiceFactory.getInstance().getService(HotelSearching.class,
				"hotelSearch");
	}

	/**
	 * Method return HotelBooking.class.
	 * 
	 * @return HotelBooking
	 */
	public static HotelBooking getHotelBooking() {
		return (HotelBooking) ServiceFactory.getInstance().getService(HotelBooking.class,
				"hotelBooking");
	}

	/**
	 * Method return BookingList.class.
	 * 
	 * @return BookingList
	 */
	public static BookingList getBookingList() {
		return (BookingList) ServiceFactory.getInstance().getService(BookingList.class,
				"bookingList");
	}

	/**
	 * Method return array of Hotel.
	 * 
	 * @return hotels array of Hotels
	 */
	public static Hotel[] getHotels() {
		List<Hotel> ls = (List<Hotel>) getBindingManager().getObject("hotels");
		Hotel[] temp = new Hotel[ls.size()];
		Hotel[] hotels = (Hotel[]) ((List<Hotel>) getBindingManager()
				.getObject("hotels")).toArray(temp);
		return hotels;
	}

	/**
	 * Method return array of Booking.
	 * 
	 * @return bookings array of Booking
	 */
	public static Booking[] getBookings() {
		List<Booking> ls = (List<Booking>) getBindingManager().getObject(
				"bookings");
		Booking[] temp = new Booking[ls.size()];
		Booking[] bookings = (Booking[]) ((List<Booking>) getBindingManager()
				.getObject("bookings")).toArray(temp);		
		return bookings;
	}
}