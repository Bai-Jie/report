/*
 * Copyright (C) 2009 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

import javax.swing.table.DefaultTableModel;
import java.util.Vector;

/**
 * @author apolyakov
 * 
 */
public class BookingTableModel extends DefaultTableModel {

  public BookingTableModel(Object[] columnNames, int rowCount) {
    super(convertToVector(columnNames), rowCount);
  }

  @Override
  public boolean isCellEditable(int row, int column) {
    return false;
  }

  protected static Vector convertToVector(Object[] anArray) {
    if (anArray == null) {
      return null;
    }
    Vector v = new Vector(anArray.length);
    for (int i = 0; i < anArray.length; i++) {
      v.addElement(anArray[i]);
    }
    return v;
  }
}
