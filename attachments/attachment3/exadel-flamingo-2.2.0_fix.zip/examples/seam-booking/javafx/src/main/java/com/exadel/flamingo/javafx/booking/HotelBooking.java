/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.booking;

import org.jboss.seam.example.booking.Hotel;

/**
 * @author abasharkevich
 *
 */
public interface HotelBooking {

    //public void confirm(Booking bookingFlamingo);
    public void confirm();

    public void selectHotel(Hotel selectedHotel);

    public void cancel();
    
    public void bookHotel();
}
