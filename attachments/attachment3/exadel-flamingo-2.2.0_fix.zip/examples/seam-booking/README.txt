BUILD INSTRUCTIONS

This project uses Sun Microsystems' library called "javafxrt-main.jar". At the time of this writing (August 2009),
due to license restrictions, this library is not distributed via Maven repositories. So we included this library in web/src/main/webapp/jnlp folder
You will need to perform a few steps before building a project with Maven:

1. Download and install JavaFX SDK for your operating system from http://www.javafx.com
   Set JAVAFX_HOME system variable. 

2. Download and install Exadel Flamingo from here http://exadel.com/web/portal/flamingo. To install Flamingo, run this command:
   $flamginoinstall 

   this will copy all dependencies to your local Maven repository

3. Generate a private key and a digital certificate. The Maven build needs them in order to sign the application.

   $cd web
   $ant -f build.xml create-keyEntry

   This command will generate a certificate whose validity period is 90 days. If you want to adjust it, you will
   need to edit "validity" attribute in the "web/build.xml" file.

NOTE:
   * You only need to perform these steps once. Once done, you can build the project the usual way by
      executing standard Maven goals: compile, package, install, etc.

   * In case if you acquire a real certificate from a certificate authority (CA):
        a. You will _not_ need to execute step 2.
        b. You will need to adjust properties in the file "web/security.properties" to reflect your keystore
           configuration.

   * The demo application also has Flex user interface. If you want to try Booking demo in Flex, download and install Flex SDK and uncomment 
     approriate partsin pom.xml and web/pom.xml. We commented out the Flex portion so that if you only want to see the JavaFX part, you don't need to     
     download Flex SDK.

   * You can also view the Flex demo online: http://demo.flamingo.exadel.com/booking/