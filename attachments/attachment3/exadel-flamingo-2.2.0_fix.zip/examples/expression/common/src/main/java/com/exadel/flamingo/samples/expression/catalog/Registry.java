/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 27-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.catalog;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public interface Registry {

	String NAME = "registry";

	Category[] getCategorys();
}
