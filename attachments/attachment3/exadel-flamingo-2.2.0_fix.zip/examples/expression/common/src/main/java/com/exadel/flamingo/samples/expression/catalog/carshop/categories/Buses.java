/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 23-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.catalog.carshop.categories;

import com.exadel.flamingo.samples.expression.catalog.carshop.Bus;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class Buses extends AbstractCategory {

	public Buses() {
		super("Buses", "This category contains buses", Bus.class);
		Bus bus = new Bus();
		bus.setName("Mercedes-Benz Tourino Reisebus");
		bus.setColor("Hellblau metallic");
		bus.setPassengersSeats(10);
		add(bus);
	}
}
