/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 23-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.catalog;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public abstract class RegistryService {

	public Category[] getCategorys() {
		Category[] returnValue = new Category[0];
		Object[] objects = (Object[]) executeExpression(createGetCategorysEL());
		if (objects != null) {
			returnValue = new Category[objects.length];
			for (int i = 0; i < objects.length; i++) {
				returnValue[i] = (Category) objects[i];
			}
		}
		return returnValue;
	}

	public Category getSelectedCategory(int categoryIndex) {
		return (Category) executeExpression(createGetSelectedCategoryEL(categoryIndex));
	}

	public Product getSelectedProduct(int categoryIndex, int productIndex) {
		return (Product) executeExpression(createGetSelectedProductEL(categoryIndex, productIndex));
	}

	protected abstract Object executeExpression(String expression);

	protected String createGetCategorysEL() {
		return Registry.NAME + ".categorys";
	}

	protected String createGetSelectedCategoryEL(int categoryIndex) {
		return Registry.NAME + ".categorys[" + categoryIndex + ']';
	}

	protected String createGetSelectedProductEL(int categoryIndex, int productIndex) {
		return createGetSelectedCategoryEL(categoryIndex) + ".products[" + productIndex + ']';
	}
}
