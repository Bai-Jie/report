/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 27-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.swing.catalog;

import com.exadel.flamingo.samples.swing.FlamingoSamplesParentFrame;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ProductCatalogSampleMainFrame extends FlamingoSamplesParentFrame<ProductCatalogSampleContent> {

	public ProductCatalogSampleMainFrame() {
		super("Exadel Flamingo. Product Catalog by EL-Expressions Sample", "{0}-expression-sample");
	}

	public static void main(String[] args) {
		defaultMain(ProductCatalogSampleMainFrame.class, args);
	}

	@Override
	protected ProductCatalogSampleContent createContent() {
		return new ProductCatalogSampleContent();
	}
}
