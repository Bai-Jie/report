/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 *
 * Created on: 05-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.swing;

import com.exadel.flamingo.expression.ExpressionService;
import com.exadel.flamingo.java.ServiceFactory;
import com.exadel.flamingo.samples.swing.FlamingoSamplesParentFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ExpressionSampleMainFrame extends FlamingoSamplesParentFrame<ExpressionSampleContent> {

	private volatile boolean promptTimeFromServer = true;
	private volatile ExpressionService service;

	/** Creates new form ExpressionSampleMainFrame */
	public ExpressionSampleMainFrame() {
		super("Exadel Flamingo. EL-Expression Sample", "{0}-expression-sample");
		addWindowListener(new java.awt.event.WindowAdapter() {

			@Override
			public void windowClosed(java.awt.event.WindowEvent event) {
				formWindowClosed(event);
			}
		});
		new Thread(new Runnable() {

			public void run() {
				while (promptTimeFromServer) {
					try {
						updateCurrentTime();
						Thread.sleep(1000);
					} catch (InterruptedException exception) {
						viewException(exception);
						promptTimeFromServer = false;
					}
				}
			}
		}).start();
	}

	@Override
	protected void factoryInitialized() {
		super.factoryInitialized();
		service = ServiceFactory.getInstance().getService(ExpressionService.class, ExpressionService.NAME);
	}

	@Override
	protected ExpressionSampleContent createContent() {
		return new ExpressionSampleContent();
	}

	private void formWindowClosed(java.awt.event.WindowEvent event) {
		promptTimeFromServer = false;
	}

	protected void sayHello(final String name) {
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				try {
					if (service != null) {
						Class[] types = new Class[]{
							String.class
						};
						Object[] parameters = new Object[]{
							name
						};
						getContent().serverSays.setText(String.valueOf(service.invokeMethod("serverAction.sayHello", String.class, types, parameters)));
						getContent().lastAccessTime.setText(String.valueOf(service.getValue("serverAction.lastAccessTime")));
					}
				} catch (Exception exception) {
					viewException(exception);
				}
			}
		});
	}

	private void updateCurrentTime() {
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				try {
					if (service != null) {
						getContent().serverTime.setText(String.valueOf(service.getValue("serverAction.currentTime")));
					}
				} catch (RuntimeException exception) {
					viewException(exception);
				}
			}
		});
	}

	public static void main(String args[]) {
		defaultMain(ExpressionSampleMainFrame.class, args);
	}
}

