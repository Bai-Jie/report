/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 26-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.mobile.catalog.io;

import com.exadel.flamingo.samples.expression.catalog.Category;
import com.exadel.flamingo.samples.expression.catalog.Product;
import com.exadel.flamingo.samples.expression.catalog.carshop.Bus;
import com.exadel.flamingo.samples.expression.catalog.carshop.Car;
import com.exadel.flamingo.samples.expression.catalog.carshop.Truck;
import com.exadel.flamingo.samples.expression.catalog.carshop.categories.Buses;
import com.exadel.flamingo.samples.expression.catalog.carshop.categories.PassengerCars;
import com.exadel.flamingo.samples.expression.catalog.carshop.categories.Trucks;
import com.exadel.flamingo.service.microedition.io.FlamingoHessianInput;
import java.io.IOException;
import java.util.Hashtable;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ProductCatalogFlamingoHessianInput extends FlamingoHessianInput {

	protected Object[] createArray(Class componentsClass, int length) throws IOException {
		if (Product.class.equals(componentsClass)) {
			return new Product[length];
		}
		if (Category.class.equals(componentsClass)) {
			return new Category[length];
		}
		return super.createArray(componentsClass, length);
	}

	protected Object createObject(Class objectClass, Hashtable fieldsValues) throws IOException {
		if (Car.class.equals(objectClass)) {
			Car car = new Car();
			fillInformationAboutCar(car, fieldsValues);
			return car;
		}
		if (Bus.class.equals(objectClass)) {
			Bus bus = new Bus();
			fillInformationAboutCar(bus, fieldsValues);
			Integer passengersSeats = (Integer) fieldsValues.get("passengersSeats");
			if (passengersSeats != null) {
				bus.setPassengersSeats(passengersSeats.intValue());
			}
			return bus;
		}
		if (Truck.class.equals(objectClass)) {
			Truck truck = new Truck();
			fillInformationAboutCar(truck, fieldsValues);
			Double tonnage = (Double) fieldsValues.get("tonnage");
			if (tonnage != null) {
				truck.setTonnage(tonnage.doubleValue());
			}
			return truck;
		}
		if (PassengerCars.class.equals(objectClass)) {
			return new PassengerCars();
		}
		if (Buses.class.equals(objectClass)) {
			return new Buses();
		}
		if (Trucks.class.equals(objectClass)) {
			return new Trucks();
		}
		return super.createObject(objectClass, fieldsValues);
	}

	private void fillInformationAboutCar(Car car, Hashtable fieldsValues) {
		car.setName((String) fieldsValues.get("name"));
		car.setDescription((String) fieldsValues.get("description"));
		Double price = (Double) fieldsValues.get("price");
		if (price != null) {
			car.setPrice(price.doubleValue());
		}
		car.setColor((String) fieldsValues.get("color"));
	}
}
