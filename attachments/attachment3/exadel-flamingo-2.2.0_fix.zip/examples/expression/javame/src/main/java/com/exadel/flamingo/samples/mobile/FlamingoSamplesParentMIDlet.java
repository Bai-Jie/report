/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 *
 * Created on: 01-12-2009
 * $Revision: 2622 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-07 09:57:03 -0800 (Mon, 07 Dec 2009) $
 */
package com.exadel.flamingo.samples.mobile;

import com.exadel.flamingo.service.microedition.FlamingoServiceFactory;
import javax.microedition.io.ConnectionNotFoundException;
import javax.microedition.io.Connector;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public abstract class FlamingoSamplesParentMIDlet extends MIDlet implements ItemCommandListener, CommandListener {

	private boolean midletPaused = false;
	private Form serverConfigurationForm;
	private ChoiceGroup serverImplementation;
	private TextField serverUrlField;
	private Alert exceptionAlert;
	private Command setServerUrlCommand;
	private Command exitCommand;
	private Command backCommand;

	/**
	 * The FlamingoSamplesParentMIDlet constructor.
	 */
	public FlamingoSamplesParentMIDlet() {
	}

	/**
	 * Performs an action assigned to the Mobile Device - MIDlet Started point.
	 */
	public void startMIDlet() {
		if (!FlamingoServiceFactory.isInitialized()) {
			switchDisplayable(null, getServerConfigurationForm());
		} else {
			factoryInitialized();
			switchDisplayable(null, getContentForm());
		}
	}

	/**
	 * Performs an action assigned to the Mobile Device - MIDlet Resumed point.
	 */
	public void resumeMIDlet() {
	}

	/**
	 * Switches a current displayable in a display. The <code>display</code> instance is taken from <code>getDisplay</code> method. This method is used by all actions in the design for switching displayable.
	 * @param alert the Alert which is temporarily set to the display; if <code>null</code>, then <code>nextDisplayable</code> is set immediately
	 * @param nextDisplayable the Displayable to be set
	 */
	public void switchDisplayable(Alert alert, Displayable nextDisplayable) {
		Display display = getDisplay();
		if (alert == null) {
			display.setCurrent(nextDisplayable);
		} else {
			display.setCurrent(alert, nextDisplayable);
		}
	}

	/**
	 * Returns an initiliazed instance of serverConfigurationForm component.
	 * @return the initialized component instance
	 */
	public Form getServerConfigurationForm() {
		if (serverConfigurationForm == null) {
			serverConfigurationForm = new Form("serverConfigurationForm", new Item[]{getServerUrlField(), getServerImplementation()});
			serverConfigurationForm.addCommand(getExitCommand());
			serverConfigurationForm.setCommandListener(this);
		}
		return serverConfigurationForm;
	}

	/**
	 * Returns an initiliazed instance of serverImplementation component.
	 * @return the initialized component instance
	 */
	public ChoiceGroup getServerImplementation() {
		if (serverImplementation == null) {
			serverImplementation = new ChoiceGroup("Select server implementation", Choice.EXCLUSIVE);
			serverImplementation.append("Spring", null);
			serverImplementation.append("Seam", null);
			serverImplementation.setSelectedFlags(new boolean[]{false, false});
		}
		return serverImplementation;
	}

	/**
	 * Returns an initiliazed instance of serverUrlField component.
	 * @return the initialized component instance
	 */
	public TextField getServerUrlField() {
		if (serverUrlField == null) {
			serverUrlField = new TextField("Enter server URL", "http://localhost:8080", 32, TextField.URL);
			serverUrlField.addCommand(getSetServerUrlCommand());
			serverUrlField.setItemCommandListener(this);
			serverUrlField.setDefaultCommand(getSetServerUrlCommand());
		}
		return serverUrlField;
	}

	/**
	 * Performs an action assigned to the setServerUrl entry-point.
	 */
	public void setServerUrl() {
		final String server = getServerUrlField().getString();
		if (server != null && server.trim().length() > 0) {
			new Thread(new Runnable() {

				public void run() {
					ChoiceGroup group = getServerImplementation();
					try {
						String implementation = group.getString(group.getSelectedIndex()).toLowerCase();
						Connector.openInputStream(createUrl(server, implementation)).close();
						String url = createComponentUrl(server, implementation);
						if (!FlamingoServiceFactory.isInitialized()) {
							FlamingoServiceFactory.initialize(url);
						}
						if (FlamingoServiceFactory.isInitialized()) {
							getServerUrlField().setConstraints(TextField.UNEDITABLE);
							factoryInitialized();
							switchDisplayable(null, getContentForm());
						}
					} catch (ConnectionNotFoundException exception) {
						Alert alert = new Alert("Exception!", "Server not found", null, AlertType.ERROR);
						alert.setTimeout(15000);
						switchDisplayable(alert, getServerConfigurationForm());
					} catch (Exception exception) {
						viewException(exception);
					}
				}
			}).start();
		}
	}

	/**
	 * Called by a system to indicated that a command has been invoked on a particular item.
	 * @param command the Command that was invoked
	 * @param displayable the Item where the command was invoked
	 */
	public void commandAction(Command command, Item item) {
		if (item == serverUrlField) {
			if (command == setServerUrlCommand) {
				setServerUrl();
			}
		}
	}

	/**
	 * Returns an initiliazed instance of setServerUrlCommand component.
	 * @return the initialized component instance
	 */
	public Command getSetServerUrlCommand() {
		if (setServerUrlCommand == null) {
			setServerUrlCommand = new Command("Set URL", Command.OK, 0);
		}
		return setServerUrlCommand;
	}

	/**
	 * Called by a system to indicated that a command has been invoked on a particular displayable.
	 * @param command the Command that was invoked
	 * @param displayable the Displayable where the command was invoked
	 */
	public void commandAction(Command command, Displayable displayable) {
		if (command == exitCommand) {
			exitMIDlet();
		}
	}

	/**
	 * Returns an initiliazed instance of exitCommand component.
	 * @return the initialized component instance
	 */
	public Command getExitCommand() {
		if (exitCommand == null) {
			exitCommand = new Command("Exit", Command.EXIT, 0);
		}
		return exitCommand;
	}

	/**
	 * Returns an initiliazed instance of exceptionAlert component.
	 * @return the initialized component instance
	 */
	public Alert getExceptionAlert() {
		if (exceptionAlert == null) {
			exceptionAlert = new Alert("Exception!", null, null, AlertType.ERROR);
			exceptionAlert.setTimeout(15000);
		}
		return exceptionAlert;
	}

	/**
	 * Returns an initiliazed instance of backCommand component.
	 * @return the initialized component instance
	 */
	public Command getBackCommand() {
		if (backCommand == null) {
			backCommand = new Command("Back", Command.BACK, 0);
		}
		return backCommand;
	}

	/**
	 * Returns a display instance.
	 * @return the display instance.
	 */
	public Display getDisplay() {
		return Display.getDisplay(this);
	}

	/**
	 * Exits MIDlet.
	 */
	public void exitMIDlet() {
		switchDisplayable(null, null);
		destroyApp(true);
		notifyDestroyed();
	}

	/**
	 * Called when MIDlet is started.
	 * Checks whether the MIDlet have been already started and initialize/starts or resumes the MIDlet.
	 */
	public void startApp() {
		if (midletPaused) {
			resumeMIDlet();
		} else {
			initialize();
			startMIDlet();
		}
		midletPaused = false;
	}

	/**
	 * Called when MIDlet is paused.
	 */
	public void pauseApp() {
		midletPaused = true;
	}

	/**
	 * Called to signal the MIDlet to terminate.
	 * @param unconditional if true, then the MIDlet has to be unconditionally terminated and all resources has to be released.
	 */
	public void destroyApp(boolean unconditional) {
	}

	protected void factoryInitialized() {
	}

	protected abstract Displayable getContentForm();

	protected abstract String createUrl(String server, String implementation);

	protected abstract String createComponentUrl(String server, String implementation);

	protected void viewException(Exception exception) {
		getExceptionAlert().setString(exception.getMessage());
		switchDisplayable(exceptionAlert, getServerConfigurationForm());
	}

	protected void initialize() {
	}
}
