/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 28-10-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.mobile.catalog.io;

import com.exadel.flamingo.samples.expression.catalog.carshop.Bus;
import com.exadel.flamingo.samples.expression.catalog.carshop.Car;
import com.exadel.flamingo.samples.expression.catalog.carshop.Truck;
import com.exadel.flamingo.service.microedition.io.FlamingoHessianOutput;
import java.io.IOException;
import java.util.Hashtable;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ProductCatalogFlamingoHessianOutput extends FlamingoHessianOutput {

	protected Hashtable storeObjectAsHashtable(Object object) throws IOException {
		Hashtable returnValue = super.storeObjectAsHashtable(object);
		if (object != null) {
			Class objectClass = object.getClass();
			if (object instanceof Car) {
				Car car = (Car) object;
				returnValue = new Hashtable();
				fillInformationAboutCar(car, returnValue);
			}
			if (Bus.class.equals(objectClass)) {
				Bus bus = (Bus) object;
				returnValue.put("passengersSeats", new Integer(bus.getPassengersSeats()));
			}
			if (Truck.class.equals(objectClass)) {
				Truck truck = (Truck) object;
				returnValue.put("tonnage", new Double(truck.getTonnage()));
			}
		}
		return returnValue;
	}

	private void fillInformationAboutCar(Car car, Hashtable fieldsValues) {
		putStringValue("color", car.getColor(), fieldsValues);
		putStringValue("description", car.getDescription(), fieldsValues);
		putStringValue("name", car.getName(), fieldsValues);
		fieldsValues.put("price", new Double(car.getPrice()));
	}

	private void putStringValue(String key, String value, Hashtable table) {
		if (value != null) {
			table.put(key, value);
		}
	}
}
