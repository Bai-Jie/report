/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.android.catalog;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import com.exadel.flamingo.samples.expression.catalog.Product;
import com.exadel.flamingo.samples.expression.catalog.RegistryService;
import java.lang.reflect.Method;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ProductInformationActivity extends Activity {

	public static final String CATEGORY_INDEX = "categoryIndex";
	public static final String PRODUCT_INDEX = "productIndex";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		RegistryService carRegistryService = ((ProductCatalogSampleApplication) getApplication()).getCarRegistryService();
		int categoryIndex = getIntent().getIntExtra(CATEGORY_INDEX, -1);
		int productIndex = getIntent().getIntExtra(PRODUCT_INDEX, -1);
		selectProduct(carRegistryService.getSelectedProduct(categoryIndex, productIndex));
	}

	protected void selectProduct(Product product) {
		if (product != null) {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
			TableLayout table = new TableLayout(this);
			table.setColumnShrinkable(1, true);
			for (Method method : product.getClass().getMethods()) {
				try {
					String name = method.getName();
					String property = null;
					if (name.startsWith("get")) {
						property = name.substring(3);
					}
					if (property == null && name.startsWith("is")) {
						property = name.substring(2);
					}
					if (property != null && !"Class".equalsIgnoreCase(property)) {
						TableRow row = new TableRow(this);
						TextView propertyView = new TextView(this);
						propertyView.setText(property);
						row.addView(propertyView);
						TextView propertyValueView = new TextView(this);
						propertyValueView.setText(String.valueOf(method.invoke(product)));
						row.addView(propertyValueView, TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
						table.addView(row);
					}
				} catch (Exception exception) {
					((ProductCatalogSampleApplication) getApplication()).viewException(getClass(), exception);
				}
			}
			setContentView(table);
		}
	}
}
