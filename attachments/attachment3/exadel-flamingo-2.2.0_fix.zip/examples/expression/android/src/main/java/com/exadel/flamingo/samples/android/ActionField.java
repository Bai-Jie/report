/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 02-11-2009
 * $Revision: 2622 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-07 09:57:03 -0800 (Mon, 07 Dec 2009) $
 */
package com.exadel.flamingo.samples.android;

import android.content.Context;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ActionField extends LinearLayout {

	private static final LayoutParams LAYOUT_PARAMS = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
	private EditText text;
	private Button actionButton;

	public ActionField(Context context, String label, String buttonLabel) {
		super(context);
		setOrientation(LinearLayout.HORIZONTAL);
		setLayoutParams(LAYOUT_PARAMS);
		text = new EditText(context);
		actionButton = new Button(context);
		actionButton.setText(buttonLabel);
		addView(new Label(context, label));
		addView(text, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
		addView(actionButton);
	}

	public Button getActionButton() {
		return actionButton;
	}

	public EditText getText() {
		return text;
	}

	@Override
	public void setEnabled(boolean enabled) {
		super.setEnabled(enabled);
		Helper.setEnabledForChilds(this);
	}
}
