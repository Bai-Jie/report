/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.android;

import com.exadel.flamingo.android.FlamingoApplication;
import com.exadel.flamingo.expression.ExpressionService;
import com.exadel.flamingo.samples.android.FlamingoSamplesParentActivity;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ExpressionSamplesParentActivity extends FlamingoSamplesParentActivity {

	private volatile ExpressionService service;

	@Override
	protected void factoryInitialized() {
		super.factoryInitialized();
		service = ((FlamingoApplication) getApplication()).getExpressionService();
	}

	protected ExpressionService getService() {
		return service;
	}

	@Override
	protected String createUrl(String server, String implementation) {
		return server + "/" + implementation + "-expression-sample/resource/hessian";
	}
}
