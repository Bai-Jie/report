/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.android.catalog;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.exadel.flamingo.samples.expression.catalog.NamedItem;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class NamedItemsAdapter extends ArrayAdapter<NamedItem> {

	public NamedItemsAdapter(Context context) {
		super(context, 0);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		TextView view = new TextView(getContext());
		NamedItem item = getItem(position);
		view.setText(item.getName());
		return view;
	}
}
