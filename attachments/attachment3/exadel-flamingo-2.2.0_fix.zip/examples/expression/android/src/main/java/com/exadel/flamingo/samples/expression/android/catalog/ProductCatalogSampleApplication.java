/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 30-11-2009
 * $Revision: 2628 $
 * Last modified: $Author: dkorotych $ $Date: 2009-12-09 05:54:05 -0800 (Wed, 09 Dec 2009) $
 */
package com.exadel.flamingo.samples.expression.android.catalog;

import android.util.Log;
import com.exadel.flamingo.android.FlamingoApplication;
import com.exadel.flamingo.samples.expression.catalog.RegistryService;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ProductCatalogSampleApplication extends FlamingoApplication {

	private RegistryService carRegistryService;

	@Override
	public void initializeFlamingoServiceFactory(String serverUrl) {
		super.initializeFlamingoServiceFactory(serverUrl);
		carRegistryService = new RegistryService() {

			@Override
			protected Object executeExpression(String expression) {
				return getExpressionService().getValue(expression);
			}
		};
	}

	public RegistryService getCarRegistryService() {
		return carRegistryService;
	}

	public void viewException(Class<?> generator, Exception exception) {
		Log.e(generator.getName(), exception.getLocalizedMessage(), exception);
	}
}
