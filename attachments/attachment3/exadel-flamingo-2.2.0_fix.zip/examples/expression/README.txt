INSTRUCTIONS

1.	In order to build the Android UI, you must perform the following steps:

	1.1	Install Android SDK and Android Platform 1.6 (http://developer.android.com/sdk/index.html)

	1.2	Set environment variable ANDROID_HOME to path where you are installed Android

	1.3	Build example by command "mvn clean install -Pandroid"

	1.4	Deploy war (seam/spring) files to server

	1.5	To run Android example you should execute Android-emulator and deploy example to it by command
		"mvn com.jayway.maven.plugins.android.generation2:maven-android-plugin:deploy" in "android" folder

	1.6	You will need to specify the IP address of the server on which you deploy this example. If you run the server
		locally and you don't know your IP address, you can get it for example with the following command
		"sudo ifconfig eth0" under Linux or "ipconfig" under Windows

2.	In order to build the JavaME UI, you must perform the following steps:

	2.1	Install JavaME SDK (http://java.sun.com/javame/downloads/)

	2.2	Set environment variable J2ME_HOME to path where you are installed JavaME

	2.3	Build example by command "mvn clean install -Pjavame"

	2.4	Deploy war (seam/spring) files to server

	2.5	To run JavaME example you should execute command "mvn j2me:run" in "javame" folder

	2.6	You will need to specify the IP address (or name) of the server on which you deploy this example. If you run
		the server locally and you don't know your IP address, you can get it for example with the following command
		"sudo ifconfig eth0" under Linux or "ipconfig" under Windows

3.	In order to build the Swing UI, you must perform the following steps:

	3.1	Build example by command "mvn clean install -Pswing"

	3.2	Deploy war (seam/spring) files to server

	3.3	To run Swing example you should execute command "mvn assembly:assembly" in "swing" folder and execute example by
		command "java -jar target/expression-sample-swing-1.0-SNAPSHOT-jar-with-dependencies.jar" or execute command
		"java -cp target/expression-sample-swing-1.0-SNAPSHOT-jar-with-dependencies.jar com.exadel.flamingo.samples.expression.swing.catalog.ProductCatalogSampleMainFrame"
		to run second example

	3.4	You will need to specify the IP address (or name) of the server on which you deploy this example. If you run
		the server locally and you don't know your IP address, you can get it for example with the following command
		"sudo ifconfig eth0" under Linux or "ipconfig" under Windows

4.	In order to build the JavaFX UI, you must perform the following steps:

	4.1	Install JavaFX SDK (http://www.javafx.net/downloads/)

	4.2	Set environment variable JAVAFX_HOME to path where you are installed JavaFX

	4.3	Generate a private key and a digital certificate. The Maven build needs them in order to sign the application.

		$cd javafx
		$ant -f build.xml create-keyEntry

		This command will generate a certificate whose validity period is 90 days. If you want to adjust it, you will
		need to edit "validity" attribute in the "javafx/build.xml" file.

		NOTE:
			*	You only need to perform these steps once. Once done, you can build the project the usual way by
				executing standard Maven goals: compile, package, install, etc.

			*	In case if you acquire a real certificate from a certificate authority (CA):
				a.	You will _not_ need to execute step 4.3
				b.	You will need to adjust properties in the file "javafx/security.properties" to reflect your
					keystore configuration.

	4.4	Build example by command "mvn clean install -Pjavafx"

	4.5	Deploy war (seam/spring) files to server

	4.6	To run the examples on JavaFX you should call the web-application, for example, using such reference
		http://localhost:8080/seam-expression-sample/ or http://localhost:8080/spring-expression-sample/
