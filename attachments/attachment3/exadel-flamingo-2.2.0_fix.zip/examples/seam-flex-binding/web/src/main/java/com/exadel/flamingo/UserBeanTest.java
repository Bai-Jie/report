/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

@Name("userBeanTest")
@Scope(ScopeType.SESSION)
public class UserBeanTest {
    private String firstName = Calendar.getInstance().getTime().toString();

    private String lastName;

    private List city = new ArrayList(2);

    public List getCity() {
        return city;
    }

    public void setCity(List city) {
        this.city = city;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    
}
