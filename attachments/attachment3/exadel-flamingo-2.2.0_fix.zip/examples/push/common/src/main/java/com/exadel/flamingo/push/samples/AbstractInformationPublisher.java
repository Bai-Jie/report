/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 05-10-2009
 * $Revision: 2271 $
 * Last modified: $Author: dkorotych $ $Date: 2009-10-08 04:30:56 -0700 (Thu, 08 Oct 2009) $
 */
package com.exadel.flamingo.push.samples;

import com.exadel.flamingo.FlamingoException;
import com.exadel.flamingo.push.EditableFlamingoMessage;
import com.exadel.flamingo.push.FlamingoObjectsFactory;
import com.exadel.flamingo.push.samples.model.ServerInfoDto;
import com.exadel.flamingo.push.server.ServerSideBroker;
import java.util.Timer;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public abstract class AbstractInformationPublisher implements InformationPublisher {

	private static final int DEFAULT_PERIOD = 10000;
	private static final String[] serverNames = new String[]{
		"serv.exadel.com",
		"db.exadel.com",
		"ns1.db.com",
		"localhost",
		"dev01.exadel.com"
	};
	private Timer timer;
	private int period = DEFAULT_PERIOD;
	private FlamingoObjectsFactory objectsFactory;
	private ServerSideBroker serverSideBroker;

	public void setPeriod(int period) throws FlamingoException {
		this.period = period;
		if (timer != null) {
			stop();
			start();
		}
	}

	public void start() {
		stop();
		objectsFactory = FlamingoObjectsFactory.getFactory();
		timer = new Timer("publisherThread");
		int index = 0;
		for (String name : getServerNames()) {
			long delay = Math.round(Math.random() * index * period);
			timer.schedule(new PrepareInformationTask(this, new ServerConfiguration(name)), delay, period);
			index = ++index % 3;
		}
	}

	@PreDestroy
	public void stop() {
		if (timer != null) {
			timer.cancel();
			timer = null;
		}
		if (objectsFactory != null) {
			objectsFactory.close();
			objectsFactory = null;
		}
	}

	public String[] getServerNames() {
		return serverNames;
	}

	protected void publishInformation(ServerInfoDto serverInfo) {
		EditableFlamingoMessage message = objectsFactory.createEditableMessage();
		message.setDestination(objectsFactory.createDestination(serverInfo.getServerName()));
		message.setTimestamp(System.currentTimeMillis());
		message.setPayloadData(serverInfo);
		message.setProperty("cpuWarning", serverInfo.getCpuWorkload() > 50.0);
		serverSideBroker.send(message);
	}

	public void setServerSideBroker(ServerSideBroker serverSideBroker) {
		this.serverSideBroker = serverSideBroker;
	}
}
