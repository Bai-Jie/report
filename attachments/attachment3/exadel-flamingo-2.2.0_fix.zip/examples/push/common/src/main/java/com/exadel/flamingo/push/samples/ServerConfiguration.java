package com.exadel.flamingo.push.samples;

import com.exadel.flamingo.push.samples.model.ServerInfoDto;
import java.util.Random;

public class ServerConfiguration {

	private Random random = new Random();
	//Server name
	private String serverName = "server";
	// Memory
	private long memoryUsed = 200000;
	private long memoryMin = 100;
	public static final long MEMORY_TOTAL = 400000;
	private long memoryMod = 100000;
	// HDD
	private int hddUsed = 124;
	private int hddMin = 10;
	public static final int HDD_TOTAL = 500;
	private int hddMod = 40;
	// HDD Speed
	private int speedWrite = 45124;
	private int speedRead = 45024;
	public static final int SPEED_MAX = 102400;
	public static final int SPEED_MIN = 10000;
	private int speedMod = 5000;
	// CPU
	private float cpuUsed = 40;
	private float cpuMod = 10;
	// UserSessions
	private int sessionsActiveCount = 10;
	private int sessionsActiveCountMin = 1;
	private int sessionsActiveCountMax = 500;
	private int sessionsActiveCountMod = 15;
	// Av. Request
	private long request = 125;
	private long requestMin = 1;
	public static final long REQUEST_MAX = 200;
	private long requestMod = 40;
	private ServerInfoDto currentValue = null;

	public ServerConfiguration() {
	}

	public ServerConfiguration(String name) {
		serverName = name;
	}

	public ServerInfoDto getNextValue() {
		if (currentValue == null) {
			currentValue = new ServerInfoDto();
			currentValue.setServerName(serverName);
			currentValue.setActiveSessionCount(sessionsActiveCount);
			currentValue.setCpuWorkload(cpuUsed);
			currentValue.setFreeMemory(MEMORY_TOTAL - memoryUsed);
			currentValue.setTotalMemory(MEMORY_TOTAL);
			currentValue.setUsedMemory(memoryUsed);
			currentValue.setHddTotalSpace(HDD_TOTAL);
			currentValue.setHddUsedSpace(hddUsed);
			currentValue.setHddFreeSpace(HDD_TOTAL - hddUsed);
			currentValue.setHddReadSpeed(speedRead);
			currentValue.setHddWriteSpeed(speedWrite);
			currentValue.setAverageRequestTime(request);
		} else {
			currentValue.setActiveSessionCount(
					getNextValue(currentValue.getActiveSessionCount(), sessionsActiveCountMod, sessionsActiveCountMin, sessionsActiveCountMax));

			currentValue.setCpuWorkload(
					getNextValue(currentValue.getCpuWorkload(), Float.valueOf(cpuMod), Float.valueOf(1), Float.valueOf(100))); //(cpuUsed);

			currentValue.setTotalMemory(MEMORY_TOTAL);
			currentValue.setUsedMemory(getNextValue(currentValue.getUsedMemory(), memoryMod, memoryMin, MEMORY_TOTAL));
			currentValue.setFreeMemory(MEMORY_TOTAL - currentValue.getUsedMemory());

			currentValue.setHddTotalSpace(HDD_TOTAL);
			currentValue.setHddUsedSpace(getNextValue(currentValue.getHddUsedSpace(), hddMod, hddMin, HDD_TOTAL));
			currentValue.setHddFreeSpace(HDD_TOTAL - currentValue.getHddUsedSpace());

			currentValue.setHddReadSpeed(getNextValue(speedRead, speedMod, SPEED_MIN, SPEED_MAX));
			currentValue.setHddWriteSpeed(getNextValue(speedWrite, speedMod, SPEED_MIN, SPEED_MAX));
			currentValue.setAverageRequestTime(getNextValue(currentValue.getAverageRequestTime(), requestMod, requestMin, REQUEST_MAX));
		}
		return currentValue;
	}

	public Integer getNextValue(Integer prevValue, Integer mod, Integer min, Integer max) {
		Integer rand = random.nextInt(mod);
		int sign = random.nextBoolean() ? -1 : 1;
		int next = prevValue + sign * rand;
		Integer nextValue = min;
		if (next > min && next < max) {
			nextValue = next;
		} else {
			nextValue = prevValue + sign * rand * -1;
		}
		return nextValue;
	}

	public Float getNextValue(Float prevValue, Float mod, Float min, Float max) {
		Float rand = random.nextFloat() * mod;
		float sign = random.nextBoolean() ? -1 : 1;
		float next = prevValue + sign * rand;
		Float nextValue = min;
		if (next > min && next <= max) {
			nextValue = next;
		} else {
			nextValue = prevValue + sign * rand * -1;
		}
		return nextValue;
	}

	public Long getNextValue(Long previousValue, Long mod, Long min, Long max) {
		Long rand = Math.round((double) random.nextFloat() * mod);
		int sign = random.nextBoolean() ? -1 : 1;
		Long next = previousValue + sign * rand;
		Long nextValue = min;
		if (next > min && next < max) {
			nextValue = next;
		} else {
			nextValue = previousValue + sign * rand * -1;
		}
		return nextValue;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public long getMemoryUsed() {
		return memoryUsed;
	}

	public void setMemoryUsed(long memoryUsed) {
		this.memoryUsed = memoryUsed;
	}

//	public long getMemoryTotal() {
//		return memoryTotal;
//	}
//
//	public void setMemoryTotal(long memoryTotal) {
//		this.memoryTotal = memoryTotal;
//	}
	public long getMemoryMod() {
		return memoryMod;
	}

	public void setMemoryMod(long memoryMod) {
		this.memoryMod = memoryMod;
	}

	public int getHddUsed() {
		return hddUsed;
	}

	public void setHddUsed(int hddUsed) {
		this.hddUsed = hddUsed;
	}

//	public int getHddTotal() {
//		return hddTotal;
//	}
//
//	public void setHddTotal(int hddTotal) {
//		this.hddTotal = hddTotal;
//	}
	public int getHddMod() {
		return hddMod;
	}

	public void setHddMod(int hddMod) {
		this.hddMod = hddMod;
	}

	public int getSpeedWrite() {
		return speedWrite;
	}

	public void setSpeedWrite(int speedWrite) {
		this.speedWrite = speedWrite;
	}

	public int getSpeedRead() {
		return speedRead;
	}

	public void setSpeedRead(int speedRead) {
		this.speedRead = speedRead;
	}

//	public int getSpeedMax() {
//		return speedMax;
//	}
//	public void setSpeedMax(int speedMax) {
//		this.speedMax = speedMax;
//	}
//
//	public int getSpeedMin() {
//		return speedMin;
//	}
//	public void setSpeedMin(int speedMin) {
//		this.speedMin = speedMin;
//	}
	public int getSpeedMod() {
		return speedMod;
	}

	public void setSpeedMod(int speedMod) {
		this.speedMod = speedMod;
	}

	public float getCpuUsed() {
		return cpuUsed;
	}

	public void setCpuUsed(float cpuUsed) {
		this.cpuUsed = cpuUsed;
	}

	public float getCpuMod() {
		return cpuMod;
	}

	public void setCpuMod(float cpuMod) {
		this.cpuMod = cpuMod;
	}

	public int getSessionsActiveCount() {
		return sessionsActiveCount;
	}

	public void setSessionsActiveCount(int sessionsActiveCount) {
		this.sessionsActiveCount = sessionsActiveCount;
	}

	public int getSessionsActiveCountMin() {
		return sessionsActiveCountMin;
	}

	public void setSessionsActiveCountMin(int sessionsActiveCountMin) {
		this.sessionsActiveCountMin = sessionsActiveCountMin;
	}

	public int getSessionsActiveCountMax() {
		return sessionsActiveCountMax;
	}

	public void setSessionsActiveCountMax(int sessionsActiveCountMax) {
		this.sessionsActiveCountMax = sessionsActiveCountMax;
	}

	public int getSessionsActiveCountMod() {
		return sessionsActiveCountMod;
	}

	public void setSessionsActiveCountMod(int sessionsActiveCountMod) {
		this.sessionsActiveCountMod = sessionsActiveCountMod;
	}

	public long getRequest() {
		return request;
	}

	public void setRequest(long request) {
		this.request = request;
	}

	public long getRequestMin() {
		return requestMin;
	}

	public void setRequestMin(long requestMin) {
		this.requestMin = requestMin;
	}

//	public long getRequestMax() {
//		return requestMax;
//	}
//
//	public void setRequestMax(long requestMax) {
//		this.requestMax = requestMax;
//	}
	public long getRequestMod() {
		return requestMod;
	}

	public void setRequestMod(long requestMod) {
		this.requestMod = requestMod;
	}

	public ServerInfoDto getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(ServerInfoDto currentValue) {
		this.currentValue = currentValue;
	}
}
