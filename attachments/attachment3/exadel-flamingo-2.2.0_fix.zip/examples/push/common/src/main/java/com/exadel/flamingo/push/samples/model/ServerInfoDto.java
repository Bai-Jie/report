package com.exadel.flamingo.push.samples.model;

import java.io.Serializable;
import java.lang.reflect.Field;

/**
 *
 * @author AYakovenko
 */
public class ServerInfoDto implements Serializable {

	/** Server name. */
	private String serverName;
	/** Active sessions count. */
	private Integer activeSessionCount;
	/** CPU workaload. */
	private Float cpuWorkload;
	/** HDD read speed. */
	private Integer hddReadSpeed;
	/** HDD write speed. */
	private Integer hddWriteSpeed;
	/** HDD total space (capacity).*/
	private Integer hddTotalSpace;
	/** HDD used space. */
	private Integer hddUsedSpace;
	/** HDD free space. */
	private Integer hddFreeSpace;
	/** Total memory size. */
	private Long totalMemory;
	/** Used memory. */
	private Long usedMemory;
	/** Unused (free) memory. */
	private Long freeMemory;
	/** Average request time. */
	private Long averageRequestTime;

	public Integer getActiveSessionCount() {
		return activeSessionCount;
	}

	public void setActiveSessionCount(Integer activeSessionCount) {
		this.activeSessionCount = activeSessionCount;
	}

	public Float getCpuWorkload() {
		return cpuWorkload;
	}

	public void setCpuWorkload(Float cpuWorkload) {
		this.cpuWorkload = cpuWorkload;
	}

	public Long getFreeMemory() {
		return freeMemory;
	}

	public void setFreeMemory(Long freeMemory) {
		this.freeMemory = freeMemory;
	}

	public Integer getHddFreeSpace() {
		return hddFreeSpace;
	}

	public void setHddFreeSpace(Integer hddFreeSpace) {
		this.hddFreeSpace = hddFreeSpace;
	}

	public Integer getHddReadSpeed() {
		return hddReadSpeed;
	}

	public void setHddReadSpeed(Integer hddReadSpeed) {
		this.hddReadSpeed = hddReadSpeed;
	}

	public Integer getHddTotalSpace() {
		return hddTotalSpace;
	}

	public void setHddTotalSpace(Integer hddTotalSpace) {
		this.hddTotalSpace = hddTotalSpace;
	}

	public Integer getHddUsedSpace() {
		return hddUsedSpace;
	}

	public void setHddUsedSpace(Integer hddUsedSpace) {
		this.hddUsedSpace = hddUsedSpace;
	}

	public Integer getHddWriteSpeed() {
		return hddWriteSpeed;
	}

	public void setHddWriteSpeed(Integer hddWriteSpeed) {
		this.hddWriteSpeed = hddWriteSpeed;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public Long getTotalMemory() {
		return totalMemory;
	}

	public void setTotalMemory(Long totalMemory) {
		this.totalMemory = totalMemory;
	}

	public Long getUsedMemory() {
		return usedMemory;
	}

	public void setUsedMemory(Long usedMemory) {
		this.usedMemory = usedMemory;
	}

	public Long getAverageRequestTime() {
		return averageRequestTime;
	}

	public void setAverageRequestTime(Long requestTime) {
		this.averageRequestTime = requestTime;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder(super.toString());
		Field[] fields = getClass().getDeclaredFields();
		if (fields.length > 0) {
			int last = fields.length - 2;
			builder.append('[');
			for (int index = 0; index < last; index++) {
				Field field = fields[index];
				appendField(field, builder);
				builder.append(", ");
			}
			appendField(fields[last], builder);
			builder.append(']');
		}
		return builder.toString();
	}

	private void appendField(Field field, StringBuilder builder) {
		builder.append(field.getName());
		builder.append(" = ");
		try {
			builder.append(field.get(this));
		} catch (Exception exception) {
			builder.append(exception.getLocalizedMessage());
		}
	}
}
