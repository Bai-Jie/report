package com.exadel.flamingo.push.samples;

import com.exadel.flamingo.push.samples.model.ServerInfoDto;
import com.exadel.flamingo.utils.EmptyReturnCommand;
import java.util.TimerTask;

/**
 *
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
class PrepareInformationTask extends TimerTask {

	private AbstractInformationPublisher publisher;
	private ServerConfiguration configuration;

	PrepareInformationTask(AbstractInformationPublisher publisher, ServerConfiguration configuration) {
		this.publisher = publisher;
		this.configuration = configuration;
	}

	@Override
	public void run() {
		new EmptyReturnCommand() {

			@Override
			protected void processingWithoutReturn() throws Exception {
				ServerInfoDto serverInfo = configuration.getNextValue();
				System.out.println("serverInfo = " + serverInfo);
				publisher.publishInformation(serverInfo);
			}
		}.execute();
	}
}
