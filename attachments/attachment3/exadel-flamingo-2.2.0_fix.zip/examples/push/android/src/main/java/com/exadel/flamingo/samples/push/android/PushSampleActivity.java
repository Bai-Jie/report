/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 29-12-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.push.android;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.exadel.flamingo.samples.android.FlamingoSamplesParentActivity;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class PushSampleActivity extends FlamingoSamplesParentActivity {

	private static final String SAMPLE_PATTERN = "-push-sample";

	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);

		Button button = new Button(this);
		button.setText("Work without connection");
		button.setOnClickListener(new OnClickListener() {

			public void onClick(View view) {
				startNestedActivity(null);
			}
		});
		getContent().addView(button);
	}

	@Override
	protected String createUrl(String server, String implementation) {
		return server + '/' + implementation + SAMPLE_PATTERN + "/resource/hessian";
	}

	@Override
	protected void factoryInitialized() {
		super.factoryInitialized();
		String serverUrl = getServerUrl();
		String url = serverUrl.substring(0, serverUrl.indexOf(SAMPLE_PATTERN) + SAMPLE_PATTERN.length()) + "/poll";
		startNestedActivity(url);
	}

	private void startNestedActivity(String url) {
		Intent intent = new Intent(this, MessagesListActivity.class);
		intent.putExtra(MessagesListActivity.POOLING_SERVLET_URL, url);
		startActivity(intent);
	}
}
