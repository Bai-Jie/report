/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 03-11-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.android;

import android.content.Context;
import android.widget.RadioButton;
import android.widget.RadioGroup;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class ServerImplementationsWidget extends RadioGroup {

	public ServerImplementationsWidget(Context context) {
		super(context);
		for (Implementation implementation : Implementation.values()) {
			RadioButton button = new RadioButton(context);
			button.setId(implementation.ordinal());
			button.setText(implementation.name());
			addView(button);
		}
		check(Implementation.SPRING.ordinal());
	}

	public String getImplementation() {
		return Implementation.values()[getCheckedRadioButtonId()].name().toLowerCase();
	}

	@Override
	public void setEnabled(boolean enabled) {
		super.setEnabled(enabled);
		Helper.setEnabledForChilds(this);
	}

	private enum Implementation {

		SEAM,
		SPRING;
	}
}
