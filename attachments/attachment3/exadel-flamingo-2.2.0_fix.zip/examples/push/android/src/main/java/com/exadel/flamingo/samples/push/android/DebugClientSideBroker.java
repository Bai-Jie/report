/*
 * Copyright (c) 2010 Exadel, Inc. All rights reserved.
 * 
 * Created on: 12-01-2010
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.push.android;

import com.exadel.flamingo.push.client.MessageStorage;
import com.exadel.flamingo.push.client.android.AndroidClientSideBroker;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class DebugClientSideBroker extends AndroidClientSideBroker {

	DebugClientSideBroker(int messagesPollPeriod, int connectionPollPeriod, String pollingServletURL) {
		super(messagesPollPeriod, connectionPollPeriod, pollingServletURL);
	}

	DebugClientSideBroker() {
	}

	@Override
	public MessageStorage getStorage() {
		return super.getStorage();
	}
}
