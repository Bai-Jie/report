/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 *
 * Created on: 29-12-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.push.android;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.exadel.flamingo.FlamingoException;
import com.exadel.flamingo.android.FlamingoApplication;
import com.exadel.flamingo.push.EditableFlamingoMessage;
import com.exadel.flamingo.push.FlamingoDestination;
import com.exadel.flamingo.push.FlamingoListener;
import com.exadel.flamingo.push.FlamingoMessage;
import com.exadel.flamingo.push.FlamingoObjectsFactory;
import com.exadel.flamingo.push.client.MessageStorage;
import com.exadel.flamingo.samples.android.ActionField;
import com.exadel.flamingo.samples.android.Helper;

/**
 *
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class MessagesListActivity extends Activity {

	public static final String POOLING_SERVLET_URL = "pollingServletURL";
	private static final String DESTINATION_NAME = "offlineDemo";
	private static final LayoutParams LAYOUT_PARAMS = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT);
	private LinearLayout content;
	private ListView listView;
	private ActionField sendMessageField;
	private FlamingoMessagesAdapter sentMessageList;
	private FlamingoMessagesAdapter receivedMessageList;
	private FlamingoMessagesAdapter storedMessageList;
	private DebugClientSideBroker broker;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		String url = getIntent().getStringExtra(POOLING_SERVLET_URL);
		if (url != null) {
			broker = new DebugClientSideBroker(2000, 2000 / 3, url);
			FlamingoApplication flamingoApplication = (FlamingoApplication) getApplication();
			broker.setAndroidServiceFactory(flamingoApplication.getAndroidServiceFactory());
			FlamingoDestination destination = FlamingoObjectsFactory.getFactory().createDestination(DESTINATION_NAME);
			broker.subscribe(destination, new FlamingoListener() {

				public void onMessage(final FlamingoMessage message) throws FlamingoException {
					MessagesListActivity.this.content.post(new Runnable() {

						public void run() {
							receivedMessageList.add(message);
						}
					});
				}

				public void onException(final FlamingoException exception) {
					MessagesListActivity.this.content.post(new Runnable() {

						public void run() {
							Log.e(MessagesListActivity.class.getName(), exception.getLocalizedMessage(), exception);
						}
					});
				}
			});
		} else {
			broker = new DebugClientSideBroker();
		}

		content = new LinearLayout(this);
		content.setLayoutParams(LAYOUT_PARAMS);
		content.setOrientation(LinearLayout.VERTICAL);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		sentMessageList = new FlamingoMessagesAdapter(this);
		receivedMessageList = new FlamingoMessagesAdapter(this);
		storedMessageList = new FlamingoMessagesAdapter(this);

		sendMessageField = new ActionField(this, getString(R.string.sendMessageFieldLabel), getString(R.string.sendMessageFieldButton));
		sendMessageField.getText().setText(R.string.sendMessageFieldText);
		sendMessageField.getActionButton().setOnClickListener(new Button.OnClickListener() {

			public void onClick(View view) {
				FlamingoObjectsFactory objectsFactory = FlamingoObjectsFactory.getFactory();
				EditableFlamingoMessage message = objectsFactory.createEditableMessage();
				message.setPayloadData(Helper.getString(sendMessageField));
				message.setDestination(objectsFactory.createDestination(DESTINATION_NAME));
				broker.send(message);
				sentMessageList.add(message);
			}
		});

		listView = new ListView(this);
		content.addView(createToolbar());
		content.addView(sendMessageField);
		content.addView(listView);
		setContentView(content);
		switchToSentMessages();
	}

	@Override
	protected void onDestroy() {
		if (broker != null) {
			broker.close();
		}
		super.onDestroy();
	}

	private ViewGroup createToolbar() {
		LinearLayout toolbar = new LinearLayout(this);
		toolbar.addView(createButton(R.string.sentMessageListButton, new View.OnClickListener() {

			public void onClick(View view) {
				switchToSentMessages();
			}
		}));
		toolbar.addView(createButton(R.string.storedMessageListButton, new View.OnClickListener() {

			public void onClick(View view) {
				switchToStoredMessages();
			}
		}));
		toolbar.addView(createButton(R.string.receivedMessageListButton, new View.OnClickListener() {

			public void onClick(View view) {
				switchToReceivedMessages();
			}
		}));
		return toolbar;
	}

	private void switchToSentMessages() {
		sendMessageField.setEnabled(true);
		listView.setAdapter(sentMessageList);
		setTitle(R.string.sentMessageListTitle);
	}

	private void switchToReceivedMessages() {
		sendMessageField.setEnabled(false);
		listView.setAdapter(receivedMessageList);
		setTitle(R.string.receivedMessageListTitle);
	}

	private void switchToStoredMessages() {
		storedMessageList.clear();
		MessageStorage storage = broker.getStorage();
		for (String messageKey : storage.getKeys()) {
			FlamingoMessage message = storage.get(messageKey);
			if (message != null) {
				storedMessageList.add(message);
			}
		}
		sendMessageField.setEnabled(false);
		listView.setAdapter(storedMessageList);
		setTitle(R.string.storedMessageListTitle);
	}

	private Button createButton(int textResourceId, View.OnClickListener listener) {
		Button button = new Button(this);
		button.setText(textResourceId);
		button.setOnClickListener(listener);
		return button;
	}
}
