package com.exadel.flamingo.push.samples.swing;

import com.exadel.flamingo.push.FlamingoMessage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.AbstractListModel;

class FlamingoMessagesListModel extends AbstractListModel {

	private List<FlamingoMessage> messages;

	public FlamingoMessagesListModel() {
		super();
		this.messages = Collections.synchronizedList(new ArrayList<FlamingoMessage>());
	}

	public void clear() {
		int index = getSize();
		messages.clear();
		this.fireContentsChanged(this, 0, index);
	}

	public boolean add(FlamingoMessage message) {
		boolean returnValue = messages.add(message);
		if (returnValue) {
			int index = messages.size() - 2;
			this.fireContentsChanged(this, index, index);
		}
		return returnValue;
	}

	public boolean remove(FlamingoMessage message) {
		int index = messages.indexOf(message);
		boolean returnValue = messages.remove(message);
		if (returnValue) {
			this.fireContentsChanged(this, index, index);
		}
		return returnValue;
	}

	public int getSize() {
		return messages.size();
	}

	public Object getElementAt(int index) {
		String returnValue = null;
		FlamingoMessage message = messages.get(index);
		if (message != null) {
			returnValue = String.valueOf(message.getPayloadData());
		}
		return returnValue;
	}
}
