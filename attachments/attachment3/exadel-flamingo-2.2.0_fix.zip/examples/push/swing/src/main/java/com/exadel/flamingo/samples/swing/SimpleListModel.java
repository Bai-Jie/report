/*
 * Copyright (c) 2009 Exadel, Inc. All rights reserved.
 * 
 * Created on: 27-11-2009
 * $Revision: 2643 $
 * Last modified: $Author: dkorotych $ $Date: 2010-01-13 05:02:19 -0800 (Wed, 13 Jan 2010) $
 */
package com.exadel.flamingo.samples.swing;

import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractListModel;

/**
 * 
 * @author Dmitry Korotych <dkorotych at exadel com>
 */
public class SimpleListModel<Type> extends AbstractListModel {

	private List<Type> itemList;

	public SimpleListModel() {
		super();
		this.itemList = new ArrayList<Type>();
	}

	public void clear() {
		int index = getSize();
		itemList.clear();
		this.fireContentsChanged(this, 0, index);
	}

	public boolean add(Type item) {
		boolean returnValue = itemList.add(item);
		if (returnValue) {
			int index = itemList.size() - 2;
			this.fireContentsChanged(this, index, index);
		}
		return returnValue;
	}

	public boolean remove(Type item) {
		int index = itemList.indexOf(item);
		boolean returnValue = itemList.remove(item);
		if (returnValue) {
			this.fireContentsChanged(this, index, index);
		}
		return returnValue;
	}

	public int getSize() {
		return itemList.size();
	}

	public Object getElementAt(int index) {
		return String.valueOf(itemList.get(index));
	}

	protected Type getElement(int index) {
		return itemList.get(index);
	}
}
