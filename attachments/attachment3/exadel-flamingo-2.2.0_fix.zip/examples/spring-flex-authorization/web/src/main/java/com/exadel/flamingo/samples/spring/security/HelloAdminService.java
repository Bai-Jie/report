/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo.samples.spring.security;

import org.springframework.stereotype.Service;

@Service("helloAdminService")
public class HelloAdminService {
    public String hello(String name) {
        return "Hello, admin " + name;
    }

}
