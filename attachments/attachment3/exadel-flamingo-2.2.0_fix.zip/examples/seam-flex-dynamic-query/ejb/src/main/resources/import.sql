insert into Person (id, name) values (1, 'John Smith')
insert into Person (id, name) values (2, 'Jack')
insert into Person (id, name) values (3, 'Ronald')
insert into Person (id, name) values (4, 'Mary')
insert into Person (id, name) values (5, 'Peter')
insert into Person (id, name) values (6, 'Forrest Gump')
insert into Person (id, name) values (7, 'Superman')
insert into Person (id, name) values (8, 'Andrew')
insert into Person (id, name) values (9, 'Alex')
insert into Person (id, name) values (10, 'Unknown')

-- for one-to-many and many-to-one relationships
insert into Book(id, title, autor, person_id) values (1, 'Java 2', 'Horstman', 1);
insert into Book(id, title, autor, person_id) values (2, 'C#', 'J.Faulz', 1);
insert into Book(id, title, autor, person_id) values (3, 'C++', 'Straustrup', 2);
insert into Book(id, title, autor, person_id) values (4, 'Core JSF', 'David Geary', 3);
insert into Book(id, title, autor, person_id) values (5, 'Core Flex', 'BAUER', 5);
insert into Book(id, title, autor, person_id) values (6, 'Seam', 'Gavin King', 5);


-- for many to many relationship
insert into Address(id, street) values (1, 'Atlantic Avenue');
insert into Address(id, street) values (2, 'Park Avenue');
insert into Address(id, street) values (3, 'Bleecker Street');
insert into Address(id, street) values (4, 'The Bowery:');
insert into Address(id, street) values (5, 'Broadway');
insert into Address(id, street) values (6, 'Madison Avenue');
insert into Address(id, street) values (7, 'Delancey Street');
insert into Address(id, street) values (8, 'Flatbush Avenue');
insert into Address(id, street) values (9, 'Fulton Street');
insert into Address(id, street) values (10, 'Houston Street');

insert into Person_Address (person_id, addresses_id) values (1, 1)
insert into Person_Address (person_id, addresses_id) values (1, 2)
insert into Person_Address (person_id, addresses_id) values (2, 2)
insert into Person_Address (person_id, addresses_id) values (2, 5)
insert into Person_Address (person_id, addresses_id) values (2, 7)
insert into Person_Address (person_id, addresses_id) values (3, 3)
insert into Person_Address (person_id, addresses_id) values (4, 4)
insert into Person_Address (person_id, addresses_id) values (5, 5)
insert into Person_Address (person_id, addresses_id) values (6, 6)
insert into Person_Address (person_id, addresses_id) values (7, 7)
insert into Person_Address (person_id, addresses_id) values (8, 8)
insert into Person_Address (person_id, addresses_id) values (9, 9)
insert into Person_Address (person_id, addresses_id) values (10, 10)


