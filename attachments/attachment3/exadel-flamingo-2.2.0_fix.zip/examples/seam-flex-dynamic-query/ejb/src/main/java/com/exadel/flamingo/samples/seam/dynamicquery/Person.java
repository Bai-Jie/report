/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 */

package com.exadel.flamingo.samples.seam.dynamicquery;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import java.util.*;
import org.hibernate.validator.Length;
import org.jboss.seam.annotations.Name;

@Entity
public class Person implements Serializable {
	
	private static final long serialVersionUID = 7090355523656267198L;
	
	private Integer id;
	private String name;
	private Set<Address> addresses; 
	private Set<Book> books;
	
	@OneToMany(mappedBy = "person", fetch = FetchType.LAZY)
	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}

	@Id @GeneratedValue
	public Integer getId() {
	     return id;
	}

	public void setId(Integer id) {
	     this.id = id;
	}
	
	@ManyToMany(fetch = FetchType.LAZY)
	public Set<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(Set<Address> addresses) {
		this.addresses = addresses;
	}

	@Length(max=20)
	public String getName() {
	     return name;
	}

	public void setName(String name) {
	     this.name = name;
	}   	
}