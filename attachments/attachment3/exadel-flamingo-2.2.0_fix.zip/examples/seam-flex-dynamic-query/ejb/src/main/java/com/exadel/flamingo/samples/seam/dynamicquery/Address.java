package com.exadel.flamingo.samples.seam.dynamicquery;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import org.jboss.seam.annotations.Name;

@Entity
public class Address implements Serializable {
	
	private static final long serialVersionUID = 3830361998472688469L;

	private Long id;
	
	private String street;

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	@Id
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
