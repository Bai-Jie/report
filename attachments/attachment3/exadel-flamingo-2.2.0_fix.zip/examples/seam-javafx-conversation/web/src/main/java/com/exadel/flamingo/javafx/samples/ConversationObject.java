/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */

package com.exadel.flamingo.javafx.samples;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

/**
 *
 * @author apleskatsevich
 */
@Name("conversationObject")
@Scope(ScopeType.CONVERSATION)
public class ConversationObject {

}
