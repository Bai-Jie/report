/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */

package com.exadel.flamingo.javafx.samples;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

/**
 *
 * @author apleskatsevich
 */
@Name("checker")
@Scope(ScopeType.STATELESS)
public class ConversationChecker {
    
    @In(required=false)
    private ConversationObject conversationObject;

    public boolean isActive() {
        return conversationObject != null;
    }
}
