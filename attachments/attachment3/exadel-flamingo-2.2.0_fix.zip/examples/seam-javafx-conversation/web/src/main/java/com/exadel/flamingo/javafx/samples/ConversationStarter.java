/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */

package com.exadel.flamingo.javafx.samples;

import org.jboss.seam.annotations.Begin;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;

/**
 *
 * @author apleskatsevich
 */
@Name("conversationStarter")
public class ConversationStarter {
    
    @Out
    private ConversationObject conversationObject;
    
    @Begin
    public void start() {
        conversationObject = new ConversationObject();
    }
}
