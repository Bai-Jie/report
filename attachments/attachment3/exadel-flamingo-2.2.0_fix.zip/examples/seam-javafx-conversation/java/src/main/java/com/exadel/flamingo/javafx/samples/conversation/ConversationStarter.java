/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */

package com.exadel.flamingo.javafx.samples.conversation;

/**
 *
 * @author apleskatsevich
 */
public interface ConversationStarter {
    public void start();
}
