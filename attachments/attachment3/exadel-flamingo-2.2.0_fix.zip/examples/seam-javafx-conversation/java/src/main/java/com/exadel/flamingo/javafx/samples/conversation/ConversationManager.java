/*
 * Copyright (C) 2008 Exadel, Inc.
 *
 * The GNU Lesser General Public License, Version 3
 *
 */
package com.exadel.flamingo.javafx.samples.conversation;

import com.exadel.flamingo.java.ServiceFactory;

/**
 *
 * @author apleskatsevich
 */
public class ConversationManager {

	public static void start() {
		((ConversationStarter) ServiceFactory.getInstance().getService(ConversationStarter.class, "conversationStarter")).start();
	}

	public static void stop() {
		((ConversationStopper) ServiceFactory.getInstance().getService(ConversationStopper.class, "conversationStopper")).stop();
	}

	public static boolean isActive() {
		return ((ConversationChecker) ServiceFactory.getInstance().getService(ConversationChecker.class, "checker")).isActive();
	}
}
